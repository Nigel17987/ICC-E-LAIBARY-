# How to Build ICC E-LIBRARY APK

## Option 1: GitHub Actions (Automatic - No PC Setup Needed)

1. Create a free account at github.com
2. Create a new repository called "ICC-E-LIBRARY"
3. Upload all these files to the repo
4. Go to Actions tab → "Build ICC E-LIBRARY APK" → Run workflow
5. Wait ~5 minutes → Download your APK from the Artifacts section

## Option 2: Build on Your PC (Windows/Mac/Linux)

### Install these first (all free):
- Node.js: https://nodejs.org (download LTS version)
- Java JDK 17: https://adoptium.net
- Android Studio: https://developer.android.com/studio

### Then run these commands:
```bash
# 1. Install project dependencies
npm install

# 2. Build the web app
npm run build

# 3. Copy built files into Android assets
mkdir -p android/app/src/main/assets
cp -r dist/* android/app/src/main/assets/

# 4. Generate a signing keystore (first time only)
cd android/app
keytool -genkey -v -keystore icc-release-key.keystore -alias icc-elibrary -keyalg RSA -keysize 2048 -validity 10000 -storepass icc@2024 -keypass icc@2024 -dname "CN=ICC E-Library, O=ICC, C=PH"
cd ../..

# 5. Build the APK
cd android
./gradlew assembleRelease

# Your APK is at:
# android/app/build/outputs/apk/release/app-release.apk
```

## Option 3: Online Builder (Easiest - No Install)

1. Deploy the dist/ folder to Netlify (netlify.com/drop) after running npm run build
2. Go to pwabuilder.com
3. Enter your Netlify URL
4. Download Android APK package

## App Details
- Package ID: com.icc.elibrary
- App Name: ICC E-LIBRARY
- Min Android: 5.1 (API 22)
- Target Android: 14 (API 34)
