import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '@/firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth();

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Test connection with retry
async function testConnection(retries = 3) {
  console.log("Starting Firestore diagnostic sync...");
  console.log("Target Project:", firebaseConfig.projectId);
  console.log("Target DB:", firebaseConfig.firestoreDatabaseId || "(default)");

  const isPlaceholder = firebaseConfig.projectId === 'remixed-project-id';
  
  if (isPlaceholder) {
    console.log("ℹ️ App is running with placeholder configuration. Database features may be limited.");
    return;
  }

  for (let i = 0; i < retries; i++) {
    try {
      // Use getDocFromServer to bypass local cache and force network check
      const testDoc = doc(db, 'test', 'connection');
      await getDocFromServer(testDoc);
      console.log("✅ Firestore node synchronization successful.");
      return;
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      
      // If it's just "not found", that's actually a successful connection (the document doesn't exist but we reached the server)
      // If it's a permission error, we also reached the server.
      if (msg.includes("insufficient permissions") || msg.includes("not-found") || (error as any)?.code === 'not-found') {
        console.log("✅ Firestore node reached (Server responded).");
        return;
      }

      console.warn(`⚠️ Firestore sync attempt ${i + 1} failed: ${msg}`);
      
      if (i === retries - 1) {
        console.warn("⚠️ Firestore node synchronization paused. Features requiring server sync may use local cache.");
      } else {
        await new Promise(resolve => setTimeout(resolve, i === 0 ? 1000 : 3000));
      }
    }
  }
}
testConnection();
