import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY || ''
});

const SYSTEM_INSTRUCTION = `
You are the "ICC e-Library Smart Guide", a helpful AI assistant for the International Computer College (ICC) student portal.
Your goal is to assist students, lecturers, and admins with information about the platform and general academic queries.

Context about ICC (International Computer College) 2024:
- We are a premier institution for computer studies.
- Main departments: Computer Science, Software Engineering, Information Technology.
- Our portal provides:
  * Course materials (PDFs, Videos, Assignments)
  * Real-time chat groups for student-lecturer interaction.
  * A personal dashboard to track academic progress.
  * A shared library of academic resources.

Your Personality:
- Professional yet encouraging.
- Concise and helpful.
- Technical when needed but understandable.
- Always sign off with a helpful tip or a positive remark.

Guidance:
- If a student asks about their grades, remind them to check the "Assignments" page.
- If they ask for course materials, direct them to the "Library" or their "Dashboard".
- Answer technical questions about Computer Science (algorithms, data structures, web dev, etc.) accurately.
- If you don't know something specific about a student's personal data (like their exact phone number), tell them to check their "Profile" or contact the "Maintenance Admin".
`;

export async function askAssistant(prompt: string, history: { role: 'user' | 'model', parts: { text: string }[] }[] = []) {
  if (!process.env.GEMINI_API_KEY) {
    throw new Error("Gemini API key is not configured.");
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        ...history.map(h => ({ role: h.role, parts: h.parts })),
        { role: "user", parts: [{ text: prompt }] }
      ],
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
    });

    return response.text || "I'm sorry, I couldn't generate a response at the moment.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
}
