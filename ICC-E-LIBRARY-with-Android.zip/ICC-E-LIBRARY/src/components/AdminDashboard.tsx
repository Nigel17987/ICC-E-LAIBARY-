import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, 
  Monitor, 
  ShieldAlert, 
  CloudUpload, 
  Database, 
  BarChart3,
  UserCheck,
  History,
  Search,
  Plus,
  Trash2,
  Edit,
  Save,
  X,
  Megaphone,
  Bell,
  Send,
  BookOpen,
  GraduationCap,
  UserPlus,
  FileText,
  Download
} from 'lucide-react';
import { BrandingFooter } from './BrandingFooter';
import { IMAGES, UserRole } from '@/src/constants';
import { cn } from '@/src/lib/utils';
import { db, handleFirestoreError } from '@/src/lib/firebase';
import { 
  collection, 
  addDoc, 
  getDocs, 
  updateDoc, 
  deleteDoc, 
  doc, 
  serverTimestamp,
  query,
  orderBy,
  limit,
  onSnapshot,
  where
} from 'firebase/firestore';

interface AppUser {
  id: string;
  name: string;
  role: UserRole;
  username: string;
  password?: string;
  studentId?: string;
  courseId?: string;
  department?: string;
}

interface Course {
  id: string;
  name: string;
  description?: string;
  lecturerId?: string;
  lecturerName?: string;
}

interface Material {
  id: string;
  title: string;
  courseName: string;
  fileName: string;
  fileUrl: string;
  lecturerName: string;
  createdAt: any;
}

interface AdminDashboardProps {
  user?: {
    name?: string;
  } | null;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ user }) => {
  const [search, setSearch] = useState('');
  const [activeTab, setActiveTab] = useState<'users' | 'courses' | 'materials'>('users');
  const [users, setUsers] = useState<AppUser[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [materials, setMaterials] = useState<Material[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showCourseModal, setShowCourseModal] = useState(false);
  const [editingUser, setEditingUser] = useState<AppUser | null>(null);
  
  const [newUser, setNewUser] = useState({
    name: '',
    role: UserRole.STUDENT,
    studentId: '',
    courseId: '',
    username: '',
    password: ''
  });

  const [newCourse, setNewCourse] = useState({
    name: '',
    description: '',
    lecturerId: ''
  });

  const [announcement, setAnnouncement] = useState({ title: '', content: '' });
  const [loading, setLoading] = useState(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [materialTitle, setMaterialTitle] = useState('');
  const [targetCoursePath, setTargetCoursePath] = useState('');

  const exportToCSV = () => {
    if (users.length === 0) {
      alert("No users to export.");
      return;
    }

    const headers = ["Name", "Role", "Username", "Student ID", "Course/Department"];
    const rows = users.map(user => [
      user.name,
      user.role,
      user.username,
      user.studentId || "",
      user.courseId || ""
    ]);

    const csvContent = [
      headers.join(","),
      ...rows.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(","))
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `icc_enrolled_users_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const provisionBulkUsers = async (role: UserRole) => {
    setLoading(true);
    try {
      const count = 3;
      const promises = [];
      for (let i = 1; i <= count; i++) {
        const randomId = Math.floor(Math.random() * 9000) + 1000;
        const name = `${role === UserRole.STUDENT ? 'Student' : 'Lecturer'} ${randomId}`;
        const username = `${role[0].toLowerCase()}${randomId}`;
        const password = role === UserRole.STUDENT ? `icc${randomId}` : `pro${randomId}`;
        
        promises.push(addDoc(collection(db, 'users'), {
          name,
          role,
          username,
          password,
          studentId: role === UserRole.STUDENT ? `ICC-2024-${randomId}` : '',
          courseId: 'General Node',
          createdAt: serverTimestamp()
        }));
      }
      await Promise.all(promises);
      alert(`Provisioned ${count} ${role}s successfully.`);
    } catch (err) {
      handleFirestoreError(err, 'create' as any, 'users');
    } finally {
      setLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      if (!materialTitle) setMaterialTitle(file.name.split('.')[0]);
    }
  };

  const handleUploadMaterial = async () => {
    if (!selectedFile || !materialTitle) return;
    setLoading(true);
    try {
      await addDoc(collection(db, 'materials'), {
        title: materialTitle,
        courseName: targetCoursePath || 'Infrastructure Node',
        fileName: selectedFile.name,
        fileUrl: URL.createObjectURL(selectedFile),
        lecturerName: 'System Admin',
        createdAt: serverTimestamp()
      });
      setSelectedFile(null);
      setMaterialTitle('');
      setTargetCoursePath('');
      alert('Central Infrastructure Resource deployed successfully.');
    } catch (err) {
      handleFirestoreError(err, 'create' as any, 'materials');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // Sync Users
    const unsubUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
      const userList = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as AppUser));
      setUsers(userList);
    }, (err) => handleFirestoreError(err, 'list' as any, 'users'));

    // Sync Courses
    const unsubCourses = onSnapshot(collection(db, 'courses'), (snapshot) => {
      const courseList = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Course));
      setCourses(courseList);
    }, (err) => handleFirestoreError(err, 'list' as any, 'courses'));

    // Sync Materials
    const unsubMaterials = onSnapshot(collection(db, 'materials'), (snapshot) => {
      const matList = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Material));
      setMaterials(matList);
    }, (err) => handleFirestoreError(err, 'list' as any, 'materials'));

    return () => {
      unsubUsers();
      unsubCourses();
      unsubMaterials();
    };
  }, []);

  const handleCreateUser = async () => {
    if (!newUser.name) {
      alert('Please enter a name.');
      return;
    }
    
    setLoading(true);
    console.log("Attempting to deploy new node account for:", newUser.name);
    
    try {
      let password = newUser.password;
      let username = newUser.username;
      
      // Auto-generate if blank
      if (!username) {
        username = (newUser.role === UserRole.STUDENT ? 's' : 'l') + 
                  newUser.name.toLowerCase().replace(/\s/g, '').substring(0, 5) + 
                  Math.floor(Math.random() * 1000);
      }

      if (!password) {
        if (newUser.role === UserRole.STUDENT) {
          password = newUser.studentId || `icc${Math.floor(Math.random() * 1000)}`;
        } else {
          password = `pro${Math.floor(Math.random() * 1000)}`;
        }
      }

      const userData = {
        name: newUser.name,
        role: newUser.role,
        username,
        password,
        studentId: newUser.studentId || '',
        courseId: newUser.courseId || '',
        createdAt: serverTimestamp()
      };

      console.log("Deploying node with data:", { ...userData, password: '***' });
      await addDoc(collection(db, 'users'), userData);
      
      console.log("Node successfully deployed to infrastructure.");
      alert(`Account for ${newUser.name} successfully deployed!`);
      setShowAddModal(false);
      setNewUser({ name: '', role: UserRole.STUDENT, studentId: '', courseId: '', username: '', password: '' });
    } catch (err) {
      console.error("Infrastructure deployment error:", err);
      const isPermissionError = String(err).includes('permission') || (err as any).code === 'permission-denied';
      alert(isPermissionError 
        ? 'Security Protocol Violation: You do not have permission to enroll nodes. Please verify your admin session.'
        : 'Deployment Hub Failure: The infrastructure could not be reached. Check network node.');
      
      try {
        handleFirestoreError(err, 'create' as any, 'users');
      } catch (e) {
        // Logged but already alerted
      }
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateUser = async () => {
    if (!editingUser || !editingUser.name) return;
    setLoading(true);
    try {
      const userRef = doc(db, 'users', editingUser.id);
      await updateDoc(userRef, {
        name: editingUser.name,
        username: editingUser.username,
        password: editingUser.password,
        role: editingUser.role,
        studentId: editingUser.studentId || '',
        courseId: editingUser.courseId || ''
      });
      setShowEditModal(false);
      setEditingUser(null);
    } catch (err) {
      handleFirestoreError(err, 'update' as any, 'users');
    } finally {
      setLoading(false);
    }
  };

  const handleEditInit = (user: AppUser) => {
    setEditingUser({ ...user });
    setShowEditModal(true);
  };

  const handleCreateCourse = async () => {
    if (!newCourse.name) return;
    setLoading(true);
    try {
      const lecturer = users.find(u => u.id === newCourse.lecturerId);
      await addDoc(collection(db, 'courses'), {
        ...newCourse,
        lecturerName: lecturer?.name || 'Unassigned',
        createdAt: serverTimestamp()
      });
      setShowCourseModal(false);
      setNewCourse({ name: '', description: '', lecturerId: '' });
    } catch (err) {
      handleFirestoreError(err, 'create' as any, 'courses');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteUser = async (id: string) => {
    if (!confirm('Are you sure you want to delete this user?')) return;
    try {
      await deleteDoc(doc(db, 'users', id));
    } catch (err) {
      handleFirestoreError(err, 'delete' as any, 'users');
    }
  };

  const handleDeleteCourse = async (id: string) => {
    if (!confirm('Delete this course?')) return;
    try {
      await deleteDoc(doc(db, 'courses', id));
    } catch (err) {
      handleFirestoreError(err, 'delete' as any, 'courses');
    }
  };

  const handleDeleteMaterial = async (id: string) => {
    if (!confirm('Permanently purge this infrastructure resource?')) return;
    try {
      await deleteDoc(doc(db, 'materials', id));
    } catch (err) {
      handleFirestoreError(err, 'delete' as any, 'materials');
    }
  };

  const handlePostAnnouncement = async () => {
    if (!announcement.title || !announcement.content) return;
    setLoading(true);
    try {
      await addDoc(collection(db, 'announcements'), {
        ...announcement,
        postedBy: 'Admin',
        createdAt: serverTimestamp()
      });
      setAnnouncement({ title: '', content: '' });
      alert('Announcement posted successfully!');
    } catch (err) {
      handleFirestoreError(err, 'create' as any, 'announcements');
    } finally {
      setLoading(false);
    }
  };

  const filteredUsers = users.filter(u => 
    u.name.toLowerCase().includes(search.toLowerCase()) || 
    u.role.toLowerCase().includes(search.toLowerCase()) ||
    u.username.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-gutter pb-xl text-on-surface">
      <motion.section 
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-primary-container rounded-3xl p-10 text-white relative overflow-hidden shadow-2xl"
      >
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-4">
            <ShieldAlert className="w-8 h-8 text-amber-400" />
            <h2 className="text-4xl font-black tracking-tighter uppercase">Admin: {user?.name || 'Super Admin'}</h2>
          </div>
          <p className="text-xl text-on-primary-container max-w-2xl font-medium leading-relaxed">
            Manage the ICC e-Library ecosystem infrastructure. Register students, lecturers, and distribute system-wide notifications.
          </p>
        </div>
        <div className="absolute right-[-2%] top-[-20%] opacity-5 text-white pointer-events-none rotate-12">
          <ShieldAlert size={400} />
        </div>
      </motion.section>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-gutter mb-gutter">
        {/* Quick Enrollment Actions */}
        <div className="lg:col-span-12">
          <div className="bg-white border border-outline-variant rounded-3xl p-6 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center text-primary border border-primary/20">
                <UserPlus className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-black text-on-surface tracking-tight uppercase">Node Enrollment Center</h3>
                <p className="text-[10px] font-black text-outline uppercase tracking-widest">Provision access for students and academic staff</p>
              </div>
            </div>
            <div className="flex items-center gap-3 w-full md:w-auto">
              <div className="flex flex-col gap-1 items-center">
                <button 
                  onClick={() => { setNewUser({...newUser, role: UserRole.STUDENT}); setShowAddModal(true); }}
                  className="w-full md:w-auto bg-blue-600 text-white px-6 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg hover:bg-blue-700 active:scale-95 transition-all flex items-center justify-center gap-2"
                >
                  <GraduationCap className="w-4 h-4" />
                  Enroll Student
                </button>
                <button 
                  onClick={() => provisionBulkUsers(UserRole.STUDENT)}
                  className="text-[8px] font-black uppercase text-blue-600 hover:underline tracking-tighter"
                >
                  + Instant Batch (3)
                </button>
              </div>

              <div className="flex flex-col gap-1 items-center">
                <button 
                  onClick={() => { setNewUser({...newUser, role: UserRole.LECTURER}); setShowAddModal(true); }}
                  className="w-full md:w-auto bg-emerald-600 text-white px-6 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg hover:bg-emerald-700 active:scale-95 transition-all flex items-center justify-center gap-2"
                >
                  <BookOpen className="w-4 h-4" />
                  Enroll Lecturer
                </button>
                <button 
                  onClick={() => provisionBulkUsers(UserRole.LECTURER)}
                  className="text-[8px] font-black uppercase text-emerald-600 hover:underline tracking-tighter"
                >
                  + Instant Batch (3)
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-gutter">
        {/* Management Area */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          <div className="bg-white border border-outline-variant rounded-3xl overflow-hidden shadow-sm flex flex-col h-[650px]">
            <div className="p-4 bg-slate-50 border-b border-outline-variant flex items-center justify-between">
              <div className="flex bg-white p-1 rounded-2xl border border-outline-variant">
                <button 
                  onClick={() => setActiveTab('users')}
                  className={cn(
                    "px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all",
                    activeTab === 'users' ? "bg-primary text-white shadow-md" : "text-outline hover:text-primary"
                  )}
                >
                  Identities
                </button>
                <button 
                  onClick={() => setActiveTab('courses')}
                  className={cn(
                    "px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all",
                    activeTab === 'courses' ? "bg-primary text-white shadow-md" : "text-outline hover:text-primary"
                  )}
                >
                  Course Nodes
                </button>
                <button 
                  onClick={() => setActiveTab('materials')}
                  className={cn(
                    "px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all",
                    activeTab === 'materials' ? "bg-primary text-white shadow-md" : "text-outline hover:text-primary"
                  )}
                >
                  Infrastructure Resources
                </button>
              </div>

              <div className="flex items-center gap-2">
                <div className="relative w-48 md:w-64">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-outline" />
                  <input 
                    type="text" 
                    placeholder="Search node..."
                    className="w-full pl-9 pr-4 py-2 bg-white border border-outline-variant rounded-xl text-[10px] font-black focus:ring-2 focus:ring-primary outline-none transition-all uppercase tracking-widest"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </div>
                {activeTab === 'users' && (
                  <>
                    <button 
                      onClick={exportToCSV}
                      title="Export Enrolled Users to CSV"
                      className="bg-slate-100 text-slate-600 p-2.5 rounded-xl border border-outline-variant hover:bg-slate-200 active:scale-95 transition-all flex items-center gap-2"
                    >
                      <Download className="w-5 h-5" />
                      <span className="text-[10px] font-black uppercase tracking-widest hidden lg:inline">Export</span>
                    </button>
                    <button 
                      onClick={() => setShowAddModal(true)}
                      className="bg-primary text-white p-2.5 rounded-xl shadow-lg hover:scale-105 active:scale-95 transition-all"
                    >
                      <Plus className="w-5 h-5" />
                    </button>
                  </>
                )}
                {activeTab === 'materials' && (
                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="bg-primary text-white p-2.5 rounded-xl shadow-lg hover:scale-105 active:scale-95 transition-all flex items-center gap-2"
                  >
                    <Plus className="w-5 h-5" />
                    <span className="text-[10px] font-black uppercase tracking-widest hidden md:inline">Seed Node</span>
                  </button>
                )}
                <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileChange} />
              </div>
            </div>
            
            <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
              {activeTab === 'users' ? (
                // Users List
                users.filter(u => u.name.toLowerCase().includes(search.toLowerCase())).map((user) => (
                  <div key={user.id} className="p-4 flex items-center justify-between hover:bg-slate-50 transition-colors">
                    <div className="flex items-center gap-4">
                      <div className={cn(
                        "w-10 h-10 rounded-xl flex items-center justify-center font-black text-xs shadow-sm",
                        user.role === UserRole.ADMIN ? "bg-amber-100 text-amber-700" : 
                        user.role === UserRole.LECTURER ? "bg-emerald-100 text-emerald-700" : "bg-blue-100 text-blue-700"
                      )}>
                        {user.role[0].toUpperCase()}
                      </div>
                      <div>
                        <h4 className="font-bold text-sm text-on-surface">{user.name}</h4>
                        <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-slate-400">
                          <span className="text-primary/60">{user.role}</span>
                          <span className="opacity-20">|</span>
                          <span>@{user.username}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      <button 
                        onClick={() => handleEditInit(user)}
                        className="p-2 text-slate-300 hover:text-primary transition-colors flex items-center gap-1 hover:bg-primary/5 rounded-lg"
                      >
                        <Edit className="w-4 h-4"/>
                        <span className="text-[8px] font-black uppercase tracking-widest hidden sm:inline">Manage</span>
                      </button>
                      <button onClick={() => handleDeleteUser(user.id)} className="p-2 text-slate-300 hover:text-error transition-colors"><Trash2 className="w-4 h-4"/></button>
                    </div>
                  </div>
                ))
              ) : activeTab === 'courses' ? (
                // Courses List
                courses.filter(c => c.name.toLowerCase().includes(search.toLowerCase())).map((course) => (
                  <div key={course.id} className="p-5 flex items-center justify-between hover:bg-slate-50 transition-colors">
                    <div className="flex items-center gap-5">
                      <div className="w-12 h-12 rounded-2xl bg-slate-100 flex items-center justify-center text-primary shadow-inner border border-outline-variant">
                        <BookOpen className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="font-black text-sm text-on-surface tracking-tight uppercase">{course.name}</h4>
                        <div className="flex items-center gap-3 mt-1">
                          <div className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
                            <GraduationCap className="w-3 h-3" />
                            {course.lecturerName}
                          </div>
                          <span className="text-[10px] font-bold text-outline uppercase tracking-tighter">{course.description || 'General studies'}</span>
                        </div>
                      </div>
                    </div>
                    <button onClick={() => handleDeleteCourse(course.id)} className="p-2.5 text-slate-300 hover:text-error transition-all hover:bg-error/5 rounded-xl">
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                ))
              ) : (
                // Materials List for Admin
                materials.filter(m => m.title.toLowerCase().includes(search.toLowerCase())).map((mat) => (
                  <div key={mat.id} className="p-5 flex items-center justify-between hover:bg-slate-50 transition-colors group">
                    <div className="flex items-center gap-5">
                      <div className="w-12 h-12 rounded-2xl bg-slate-100 flex items-center justify-center text-on-surface-variant shadow-inner border border-outline-variant group-hover:bg-primary group-hover:text-white transition-all">
                        <FileText className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="font-black text-sm text-on-surface tracking-tight uppercase">{mat.title}</h4>
                        <div className="flex items-center gap-3 mt-1">
                          <div className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-primary bg-primary/5 px-2 py-0.5 rounded-full border border-primary/10">
                            {mat.lecturerName}
                          </div>
                          <span className="text-[10px] font-bold text-outline uppercase tracking-tighter">{mat.fileName} • {mat.courseName}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                       <a href={mat.fileUrl} download={mat.fileName} className="p-2 text-slate-300 hover:text-primary transition-colors">
                          <Download size={20} />
                       </a>
                       <button onClick={() => handleDeleteMaterial(mat.id)} className="p-2 text-slate-300 hover:text-error transition-all hover:bg-error/5 rounded-xl">
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
              {(activeTab === 'users' ? users : activeTab === 'courses' ? courses : materials).length === 0 && (
                <div className="p-24 text-center">
                  <Database className="w-12 h-12 text-slate-200 mx-auto mb-4" />
                  <p className="text-xs font-black uppercase tracking-[0.2em] text-slate-300">No data indexed in this node</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Announcements & Quick Actions */}
        <div className="lg:col-span-4 flex flex-col gap-gutter">
          <div className="bg-white border border-outline-variant rounded-3xl p-6 shadow-sm">
            <h3 className="text-xs font-black uppercase tracking-widest text-on-surface-variant mb-6 flex items-center gap-2">
              <Megaphone className="w-4 h-4 text-secondary" />
              Broadcasting Hub
            </h3>
            <div className="space-y-4">
              <input 
                type="text" 
                placeholder="Alert Title..."
                className="w-full p-3 bg-slate-50 border border-outline-variant rounded-xl text-xs font-bold outline-none focus:ring-2 focus:ring-secondary transition-all"
                value={announcement.title}
                onChange={(e) => setAnnouncement({...announcement, title: e.target.value})}
              />
              <textarea 
                placeholder="Compose announcement message..."
                rows={4}
                className="w-full p-3 bg-slate-50 border border-outline-variant rounded-xl text-xs font-medium outline-none focus:ring-2 focus:ring-secondary transition-all resize-none"
                value={announcement.content}
                onChange={(e) => setAnnouncement({...announcement, content: e.target.value})}
              />
              <button 
                onClick={handlePostAnnouncement}
                disabled={loading}
                className="w-full bg-secondary text-on-secondary-fixed py-3 rounded-xl font-black text-xs uppercase tracking-widest shadow-lg hover:shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                {loading ? <Bell className="w-4 h-4 animate-bounce" /> : <Send className="w-4 h-4" />}
                Init Broadcast
              </button>
            </div>
          </div>

          <div className="bg-primary-container text-white rounded-3xl p-6 shadow-xl relative overflow-hidden">
            <h3 className="text-xs font-black uppercase tracking-widest opacity-60 mb-4">Security Stats</h3>
            <div className="space-y-4 relative z-10">
              <div className="flex items-center justify-between">
                <span className="text-3xl font-black leading-none">{users.length}</span>
                <Users className="w-6 h-6 opacity-40" />
              </div>
              <p className="text-[10px] font-bold uppercase tracking-widest opacity-80">Total Active Domain Nodes</p>
            </div>
            <div className="absolute -bottom-4 -right-4 opacity-10">
              <Database size={100} />
            </div>
          </div>
        </div>
      </div>

      {/* Add User Modal */}
      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddModal(false)}
              className="absolute inset-0 bg-on-surface/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, y: 20, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.9, y: 20, opacity: 0 }}
              className="relative bg-white w-full max-w-md rounded-3xl p-8 shadow-2xl border border-outline-variant"
            >
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-xl font-black text-primary tracking-tighter uppercase">
                  {newUser.role === UserRole.STUDENT ? 'Student Enrollment' : 'Lecturer Enrollment'}
                </h3>
                <button onClick={() => setShowAddModal(false)} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Full Legal Name</label>
                  <input 
                    type="text" 
                    className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-bold outline-none focus:border-primary transition-all"
                    placeholder="Enter student/lecturer name"
                    value={newUser.name}
                    onChange={(e) => setNewUser({...newUser, name: e.target.value})}
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Access Tier</label>
                  <div className="grid grid-cols-2 gap-3">
                    {[UserRole.STUDENT, UserRole.LECTURER].map(role => (
                      <button
                        key={role}
                        onClick={() => setNewUser({...newUser, role})}
                        className={cn(
                          "py-3 rounded-xl border-2 font-black text-[10px] uppercase tracking-widest transition-all",
                          newUser.role === role ? "border-primary bg-primary-container/10 text-primary" : "border-outline-variant text-outline hover:border-slate-300"
                        )}
                      >
                        {role}
                      </button>
                    ))}
                  </div>
                </div>

                {newUser.role === UserRole.STUDENT && (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Academic ID Number</label>
                      <input 
                        type="text" 
                        className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-bold outline-none focus:border-primary transition-all"
                        placeholder="ICC-2024-XXXX"
                        value={newUser.studentId}
                        onChange={(e) => setNewUser({...newUser, studentId: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Course Node</label>
                      <input 
                        type="text" 
                        className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-bold outline-none focus:border-primary transition-all"
                        placeholder="e.g. B-Tech IT"
                        value={newUser.courseId}
                        onChange={(e) => setNewUser({...newUser, courseId: e.target.value})}
                      />
                    </div>
                  </div>
                )}

                {newUser.role === UserRole.LECTURER && (
                  <div>
                    <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Course / Department Designation</label>
                    <input 
                      type="text" 
                      className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-bold outline-none focus:border-primary transition-all"
                      placeholder="e.g. Computer Science Department"
                      value={newUser.courseId}
                      onChange={(e) => setNewUser({...newUser, courseId: e.target.value})}
                    />
                  </div>
                )}

                <div className="pt-4">
                  <div className="space-y-4 mb-6">
                    <div>
                      <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Custom Username (Optional)</label>
                      <input 
                        type="text" 
                        className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-bold outline-none focus:border-primary transition-all"
                        placeholder="Leave blank for auto-generation"
                        value={newUser.username}
                        onChange={(e) => setNewUser({...newUser, username: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Access Password (Optional)</label>
                      <input 
                        type="text" 
                        className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-bold outline-none focus:border-primary transition-all"
                        placeholder="Leave blank for smart defaults"
                        value={newUser.password}
                        onChange={(e) => setNewUser({...newUser, password: e.target.value})}
                      />
                    </div>
                  </div>
                  <div className="p-4 bg-blue-50 rounded-2xl border border-blue-100 mb-6">
                    <p className="text-[10px] font-bold text-blue-600 leading-relaxed uppercase tracking-wider">
                      Initial credentials will be auto-generated if left blank. Students use ID as password by default.
                    </p>
                  </div>
                  <button 
                    onClick={handleCreateUser}
                    disabled={loading}
                    className="w-full bg-primary text-white py-4 rounded-2xl font-black uppercase tracking-widest shadow-xl hover:bg-primary-container active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                  >
                    {loading ? <History className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                    Deploy New Node Account
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Edit User Modal */}
      <AnimatePresence>
        {showEditModal && editingUser && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => { setShowEditModal(false); setEditingUser(null); }}
              className="absolute inset-0 bg-on-surface/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, y: 20, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.9, y: 20, opacity: 0 }}
              className="relative bg-white w-full max-w-md rounded-3xl p-8 shadow-2xl border border-outline-variant"
            >
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-xl font-black text-primary tracking-tighter">Update Node Identity</h3>
                <button onClick={() => { setShowEditModal(false); setEditingUser(null); }} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Display Name</label>
                  <input 
                    type="text" 
                    className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-bold outline-none focus:border-primary transition-all"
                    value={editingUser.name}
                    onChange={(e) => setEditingUser({...editingUser, name: e.target.value})}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Username (Node ID)</label>
                    <input 
                      type="text" 
                      className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-bold outline-none focus:border-primary transition-all"
                      value={editingUser.username}
                      onChange={(e) => setEditingUser({...editingUser, username: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Access Password</label>
                    <input 
                      type="text" 
                      className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-bold outline-none focus:border-primary transition-all"
                      value={editingUser.password || ''}
                      onChange={(e) => setEditingUser({...editingUser, password: e.target.value})}
                    />
                  </div>
                </div>

                {editingUser.role === UserRole.STUDENT && (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Student Identifier</label>
                      <input 
                        type="text" 
                        className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-bold outline-none focus:border-primary transition-all"
                        value={editingUser.studentId || ''}
                        onChange={(e) => setEditingUser({...editingUser, studentId: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Course Node</label>
                      <input 
                        type="text" 
                        className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-bold outline-none focus:border-primary transition-all"
                        value={editingUser.courseId || ''}
                        onChange={(e) => setEditingUser({...editingUser, courseId: e.target.value})}
                      />
                    </div>
                  </div>
                )}

                {editingUser.role === UserRole.LECTURER && (
                  <div>
                    <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Linked Course / Department</label>
                    <input 
                      type="text" 
                      className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-bold outline-none focus:border-primary transition-all"
                      placeholder="Enter Course or Department"
                      value={editingUser.courseId || ''}
                      onChange={(e) => setEditingUser({...editingUser, courseId: e.target.value})}
                    />
                  </div>
                )}

                <div className="pt-4">
                  <button 
                    onClick={handleUpdateUser}
                    disabled={loading}
                    className="w-full bg-primary text-white py-4 rounded-2xl font-black uppercase tracking-widest shadow-xl hover:bg-primary-container active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                  >
                    {loading ? <History className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                    Synchronize Changes
                  </button>
                  <button 
                     onClick={() => handleDeleteUser(editingUser.id)}
                     className="w-full mt-3 bg-error/10 text-error py-4 rounded-2xl font-black uppercase tracking-widest border border-error/20 hover:bg-error/20 transition-all flex items-center justify-center gap-2"
                  >
                    <Trash2 className="w-5 h-5" />
                    Decommission Node
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showCourseModal && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowCourseModal(false)}
              className="absolute inset-0 bg-on-surface/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, y: 20, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.9, y: 20, opacity: 0 }}
              className="relative bg-white w-full max-w-md rounded-3xl p-8 shadow-2xl border border-outline-variant"
            >
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-xl font-black text-primary tracking-tighter">Initialize Course Node</h3>
                <button onClick={() => setShowCourseModal(false)} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Course Designation</label>
                  <input 
                    type="text" 
                    className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-bold outline-none focus:border-primary transition-all"
                    placeholder="e.g. Web App Development"
                    value={newCourse.name}
                    onChange={(e) => setNewCourse({...newCourse, name: e.target.value})}
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Descriptor (Brief)</label>
                  <input 
                    type="text" 
                    className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-bold outline-none focus:border-primary transition-all"
                    placeholder="Brief objective of the course"
                    value={newCourse.description}
                    onChange={(e) => setNewCourse({...newCourse, description: e.target.value})}
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Command Lecturer</label>
                  <select 
                    className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-bold outline-none focus:border-primary transition-all appearance-none"
                    value={newCourse.lecturerId}
                    onChange={(e) => setNewCourse({...newCourse, lecturerId: e.target.value})}
                  >
                    <option value="">Select a Lecturer Node</option>
                    {users.filter(u => u.role === UserRole.LECTURER).map(u => (
                      <option key={u.id} value={u.id}>{u.name}</option>
                    ))}
                  </select>
                </div>

                <div className="pt-4">
                  <button 
                    onClick={handleCreateCourse}
                    disabled={loading || !newCourse.name}
                    className="w-full bg-primary text-white py-4 rounded-2xl font-black uppercase tracking-widest shadow-xl hover:bg-primary-container active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                  >
                    {loading ? <History className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                    Deploy Course Node
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      {/* Material Upload Confirmation Modal */}
      <AnimatePresence>
        {selectedFile && (
          <div className="fixed inset-0 z-[250] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedFile(null)}
              className="absolute inset-0 bg-on-surface/60 backdrop-blur-md"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative bg-white w-full max-w-md rounded-3xl p-8 shadow-2xl"
            >
              <h3 className="text-xl font-black text-primary uppercase tracking-tighter mb-6">Initialize Resource Node</h3>
              <div className="space-y-4">
                <div>
                  <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Material Title</label>
                  <input 
                    type="text" 
                    className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-bold outline-none focus:border-primary transition-all"
                    value={materialTitle}
                    onChange={(e) => setMaterialTitle(e.target.value)}
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Assignment Path (Optional)</label>
                  <input 
                    type="text" 
                    className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-bold outline-none focus:border-primary transition-all"
                    placeholder="e.g. CS-402 Advanced AI"
                    value={targetCoursePath}
                    onChange={(e) => setTargetCoursePath(e.target.value)}
                  />
                </div>
                <div className="p-4 bg-blue-50/50 rounded-2xl border border-blue-100 flex items-center gap-3">
                   <FileText className="text-blue-600" />
                   <div className="flex-1 min-w-0">
                     <p className="text-xs font-black text-blue-900 truncate uppercase mt-1">{selectedFile.name}</p>
                     <p className="text-[8px] font-bold text-blue-600 uppercase tracking-widest">{(selectedFile.size / 1024).toFixed(1)} KB • Local Buffer</p>
                   </div>
                </div>
                <div className="flex gap-3 pt-4">
                  <button 
                    onClick={() => setSelectedFile(null)}
                    className="flex-1 py-4 text-[10px] font-black uppercase tracking-widest text-outline hover:bg-slate-50 rounded-2xl transition-colors"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={handleUploadMaterial}
                    disabled={loading || !materialTitle}
                    className="flex-1 bg-primary text-white py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg hover:brightness-110 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                  >
                    {loading ? <History className="animate-spin w-4 h-4" /> : <Save className="w-4 h-4" />}
                    Broadcast Node
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <BrandingFooter />
    </div>
  );
};

