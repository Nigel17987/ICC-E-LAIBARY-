import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bot, X, Send, Minus, Maximize2, MessageSquare, Loader2, Sparkles } from 'lucide-react';
import { askAssistant } from '@/src/services/geminiService';
import { cn } from '@/src/lib/utils';

interface Message {
  role: 'user' | 'model';
  text: string;
}

export const AIAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: 'Hello! I am your ICC Smart Guide. How can I assist you today?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setIsLoading(true);

    try {
      // Map history to the format expected by the service
      const history = messages.map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));

      const response = await askAssistant(userMessage, history);
      setMessages(prev => [...prev, { role: 'model', text: response }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'model', text: "I'm having trouble connecting to the brain right now. Please try again later." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {/* Floating Button */}
      <motion.button
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsOpen(true)}
        className={cn(
          "fixed bottom-40 right-6 z-[100] w-14 h-14 rounded-full bg-white text-white shadow-2xl flex items-center justify-center transition-all overflow-hidden border-2 border-primary ring-4 ring-black/5",
          isOpen && "scale-0 opacity-0 pointer-events-none"
        )}
      >
        <img 
          src="https://lh3.googleusercontent.com/aida-public/AB6AXuDsSj_7MQiK8QB8TfHAGuP0b6_lxXq8tpn0jzOtsmroFty1CfEj_MPKrJlQ3-iUTe16VhwjloF2QuylINf4Xa4TBmQLuhb39og5yriJeyoC9gsONBeAMqL44_bXmXbUzrB7LEAmhx_m0SUjqdy9wpUnR7a-UjpcW0loTgSDWb_CopK_cF0IfzNr9EKNhJlwsoYmW5grN9dIXdHm43WuZoEVy40iHHZeKfwkDTTu4dlo7VEWhrRZJAW6BQLRafTNIaPEnMRGrTXxJQk" 
          className="w-full h-full object-cover" 
          alt="Avatar"
          referrerPolicy="no-referrer"
          onError={(e) => {
            (e.target as HTMLImageElement).src = 'https://ui-avatars.com/api/?name=AI&background=0284c7&color=fff';
          }}
        />
        <motion.div 
          animate={{ scale: [1, 1.2, 1], opacity: [1, 0.5, 1] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="absolute -top-1 -right-1 w-4 h-4 bg-secondary rounded-full border-2 border-white"
        />
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.8 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.8 }}
            className="fixed bottom-40 right-6 z-[101] w-[380px] h-[550px] max-w-[calc(100vw-3rem)] max-h-[calc(100vh-8rem)] bg-white rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.15)] flex flex-col overflow-hidden border border-outline-variant"
          >
            {/* Header */}
            <div className="bg-primary p-4 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-white overflow-hidden flex items-center justify-center backdrop-blur-md shadow-inner border border-white/20">
                  <img 
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuDsSj_7MQiK8QB8TfHAGuP0b6_lxXq8tpn0jzOtsmroFty1CfEj_MPKrJlQ3-iUTe16VhwjloF2QuylINf4Xa4TBmQLuhb39og5yriJeyoC9gsONBeAMqL44_bXmXbUzrB7LEAmhx_m0SUjqdy9wpUnR7a-UjpcW0loTgSDWb_CopK_cF0IfzNr9EKNhJlwsoYmW5grN9dIXdHm43WuZoEVy40iHHZeKfwkDTTu4dlo7VEWhrRZJAW6BQLRafTNIaPEnMRGrTXxJQk" 
                    className="w-full h-full object-cover" 
                    alt="Avatar"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = 'https://ui-avatars.com/api/?name=AI&background=0284c7&color=fff';
                    }}
                  />
                </div>
                <div>
                  <h3 className="font-bold text-sm">ICC Smart Guide</h3>
                  <div className="flex items-center gap-1">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    <span className="text-[10px] font-black uppercase tracking-widest text-white/70">AI Active</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button 
                  onClick={() => setIsOpen(false)}
                  className="p-2 hover:bg-white/10 rounded-xl transition-colors"
                >
                  <Minus className="w-5 h-5" />
                </button>
                <button 
                  onClick={() => setIsOpen(false)}
                  className="p-2 hover:bg-white/10 rounded-xl transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Chat Area */}
            <div 
              ref={scrollRef}
              className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/50"
            >
              {messages.map((msg, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: msg.role === 'user' ? 20 : -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className={cn(
                    "flex gap-3",
                    msg.role === 'user' ? "flex-row-reverse" : "flex-row"
                  )}
                >
                  {msg.role === 'model' && (
                    <div className="w-8 h-8 rounded-full overflow-hidden border border-outline-variant shrink-0 mt-1 bg-white flex items-center justify-center">
                      <img 
                        src="https://lh3.googleusercontent.com/aida-public/AB6AXuDsSj_7MQiK8QB8TfHAGuP0b6_lxXq8tpn0jzOtsmroFty1CfEj_MPKrJlQ3-iUTe16VhwjloF2QuylINf4Xa4TBmQLuhb39og5yriJeyoC9gsONBeAMqL44_bXmXbUzrB7LEAmhx_m0SUjqdy9wpUnR7a-UjpcW0loTgSDWb_CopK_cF0IfzNr9EKNhJlwsoYmW5grN9dIXdHm43WuZoEVy40iHHZeKfwkDTTu4dlo7VEWhrRZJAW6BQLRafTNIaPEnMRGrTXxJQk" 
                        className="w-full h-full object-cover" 
                        alt="AI"
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'https://ui-avatars.com/api/?name=AI&background=0284c7&color=fff';
                        }}
                      />
                    </div>
                  )}
                  <div className={cn(
                    "max-w-[75%] p-3 px-4 rounded-2xl text-sm shadow-sm",
                    msg.role === 'user' 
                      ? "bg-primary text-white rounded-br-none" 
                      : "bg-white text-on-surface border border-outline-variant rounded-bl-none"
                  )}>
                    {msg.text}
                  </div>
                </motion.div>
              ))}
              {isLoading && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex justify-start"
                >
                  <div className="bg-white border border-outline-variant p-3 px-4 rounded-2xl rounded-bl-none flex items-center gap-2 text-outline shadow-sm">
                    <Loader2 className="w-4 h-4 animate-spin text-primary" />
                    <span className="text-xs font-bold uppercase tracking-widest">Thinking...</span>
                  </div>
                </motion.div>
              )}
            </div>

            {/* Input Area */}
            <div className="p-4 bg-white border-t border-outline-variant">
              <div className="flex items-end gap-2 bg-slate-50 rounded-2xl p-2 border border-outline-variant focus-within:border-primary transition-all">
                <textarea
                  className="flex-1 bg-transparent border-none outline-none p-2 text-sm max-h-24 min-h-[44px] resize-none"
                  placeholder="Ask about materials, grades, or tech..."
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSend();
                    }
                  }}
                />
                <button
                  onClick={handleSend}
                  disabled={!input.trim() || isLoading}
                  className={cn(
                    "p-2.5 rounded-xl transition-all",
                    input.trim() && !isLoading 
                      ? "bg-primary text-white shadow-lg active:scale-95" 
                      : "bg-slate-200 text-slate-400 cursor-not-allowed"
                  )}
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
              <div className="mt-2 flex items-center justify-center gap-1.5 opacity-50">
                <Sparkles className="w-3 h-3 text-secondary" />
                <span className="text-[10px] font-black uppercase tracking-tighter">Powered by Gemini AI</span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
