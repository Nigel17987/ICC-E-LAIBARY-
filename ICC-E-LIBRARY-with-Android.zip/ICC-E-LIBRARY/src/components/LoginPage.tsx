import React, { useState } from 'react';
import { UserRole, IMAGES } from '@/src/constants';
import { UserCircle, Lock, ChevronRight, HelpCircle, Loader2, Eye, EyeOff } from 'lucide-react';
import { motion } from 'motion/react';
import { db, handleFirestoreError, auth } from '@/src/lib/firebase';
import { collection, query, where, getDocs, limit } from 'firebase/firestore';
import { signInAnonymously } from 'firebase/auth';

interface LoginProps {
  onLogin: (role: UserRole, user?: any) => void;
}

export const LoginPage: React.FC<LoginProps> = ({ onLogin }) => {
  const [role, setRole] = useState<UserRole>(UserRole.STUDENT);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async () => {
    if (!username || !password) return;
    setLoading(true);
    setError('');

    try {
      // For Admin, check against current env or special Firestore admin
      if (role === UserRole.ADMIN && username === 'jricc2024' && password === 'iccyourfuture@2024') {
        onLogin(UserRole.ADMIN, { name: 'Super Admin', role: UserRole.ADMIN });
        return;
      }

      const q = query(
        collection(db, 'users'), 
        where('username', '==', username), 
        where('password', '==', password),
        where('role', '==', role),
        limit(1)
      );
      
      const snapshot = await getDocs(q);
      
      if (snapshot.empty) {
        setError('Invalid credentials for selected role.');
      } else {
        const userData = { id: snapshot.docs[0].id, ...snapshot.docs[0].data() };
        onLogin(role, userData);
      }
    } catch (err) {
      handleFirestoreError(err, 'get' as any, 'users');
      setError('Connection failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-[calc(100vh-4rem)] flex-col items-center justify-center p-gutter">
      <div className="w-full max-w-md flex flex-col items-center">
        {/* Logo Section */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 w-24 h-24 rounded-full overflow-hidden bg-white flex items-center justify-center border-4 border-white shadow-xl shadow-blue-600/10"
        >
          <img src={IMAGES.LOGO} alt="ICC Logo" className="w-full h-full object-cover" />
        </motion.div>

        {/* Right Side: Form */}
        <section className="flex flex-col items-center w-full mx-auto">
          <div className="w-full space-y-6 bg-white/60 backdrop-blur-xl p-8 rounded-3xl shadow-xl border border-white mb-10">
            {error && (
              <motion.div 
                initial={{ opacity: 0, x: -10 }} 
                animate={{ opacity: 1, x: 0 }}
                className="bg-red-50 border border-red-100 text-red-600 p-3 rounded-xl text-xs font-bold uppercase tracking-widest text-center"
              >
                {error}
              </motion.div>
            )}

            <div>
              <label className="block text-xs font-black text-outline uppercase tracking-widest mb-2 px-1" htmlFor="role">Access Role</label>
              <div className="relative group">
                <select 
                  className="w-full bg-white border border-outline-variant rounded-xl py-3.5 px-4 text-sm font-bold focus:ring-4 focus:ring-blue-50 focus:border-primary-container outline-none appearance-none transition-all cursor-pointer group-hover:border-primary"
                  id="role"
                  value={role}
                  onChange={(e) => setRole(e.target.value as UserRole)}
                >
                  <option value={UserRole.STUDENT}>Student Portal</option>
                  <option value={UserRole.LECTURER}>Lecturer Portal</option>
                  <option value={UserRole.ADMIN}>Maintenance Admin</option>
                </select>
                <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-outline group-hover:text-primary transition-colors">
                  <ChevronRight className="w-4 h-4 rotate-90" />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-black text-outline uppercase tracking-widest mb-2 px-1" htmlFor="id">Username</label>
              <div className="relative group">
                <UserCircle className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-outline group-focus-within:text-primary transition-colors" />
                <input 
                  className="w-full bg-white border border-outline-variant rounded-xl py-3.5 pl-12 pr-4 text-sm font-medium focus:ring-4 focus:ring-blue-50 focus:border-primary-container outline-none transition-all hover:border-primary" 
                  id="id" 
                  placeholder="Enter your username" 
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  type="text" 
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-black text-outline uppercase tracking-widest mb-2 px-1" htmlFor="password">Password Key</label>
              <div className="relative group">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-outline group-focus-within:text-primary transition-colors" />
                <input 
                  className="w-full bg-white border border-outline-variant rounded-xl py-3.5 pl-12 pr-12 text-sm font-medium focus:ring-4 focus:ring-blue-50 focus:border-primary-container outline-none transition-all hover:border-primary" 
                  id="password" 
                  placeholder="••••••••" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  type={showPassword ? 'text' : 'password'} 
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-outline hover:text-primary transition-colors focus:outline-none"
                >
                  {showPassword ? (
                    <EyeOff className="w-5 h-5" />
                  ) : (
                    <Eye className="w-5 h-5" />
                  )}
                </button>
              </div>
            </div>

            <button 
              onClick={handleLogin}
              disabled={loading}
              className="w-full bg-primary-container text-white font-black text-lg py-5 rounded-2xl shadow-xl hover:bg-primary hover:shadow-2xl transition-all active:scale-[0.98] duration-150 flex items-center justify-center gap-2 group disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? <Loader2 className="w-6 h-6 animate-spin text-white/50" /> : 'Sign into Library'}
              <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>

            <div className="pt-6 border-t border-slate-100 flex justify-center items-center gap-2">
              <span className="text-[10px] font-black text-outline uppercase tracking-widest">Technical Support</span>
              <button className="text-[10px] font-black text-on-secondary-fixed bg-secondary-fixed px-3 py-1 rounded-full hover:bg-amber-100 transition-colors flex items-center gap-1.5">
                <HelpCircle className="w-3 h-3" />
                Help Desk
              </button>
            </div>
          </div>
        </section>

        <div className="text-center space-y-4 mt-8 pb-12">
          <div className="space-y-1">
            <h2 className="text-2xl font-black tracking-tight text-blue-600 uppercase md:text-3xl">
              INTERNATIONAL COMPUTER COLLEGE
            </h2>
            <p className="text-xl font-bold italic text-blue-900 md:text-2xl">
              "Learn Today, Lead Tomorrow"
            </p>
          </div>
          
          <div className="pt-6 border-t border-slate-200/50">
            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-outline/60 leading-loose">
              developed By <span className="text-primary">Nigel Maluge</span>
            </p>
            <p className="text-[9px] font-bold uppercase tracking-widest text-outline/40 mt-1">
              © International Computer College 2026
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

