import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  Library, 
  MessageSquare, 
  Bell, 
  Calendar, 
  Settings, 
  UserCircle,
  X,
  Megaphone,
  CheckCircle2
} from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { IMAGES, MOCK_USERS, UserRole } from '@/src/constants';
import { collection, query, orderBy, limit, onSnapshot, getDocs } from 'firebase/firestore';
import { db } from '@/src/lib/firebase';

interface NavProps {
  role: UserRole;
}

export const Header: React.FC<NavProps> = ({ role }) => {
  const user = MOCK_USERS[role];
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [hasUnread, setHasUnread] = useState(false);
  const [lastReadId, setLastReadId] = useState<string | null>(localStorage.getItem('last_read_announcement'));

  useEffect(() => {
    const q = query(collection(db, 'announcements'), orderBy('createdAt', 'desc'), limit(5));
    const unsub = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setAnnouncements(docs);
      
      if (docs.length > 0) {
        const latestId = docs[0].id;
        if (latestId !== lastReadId) {
          setHasUnread(true);
        }
      }
    });

    return () => unsub();
  }, [lastReadId]);

  const handleToggleNotifications = () => {
    setShowNotifications(!showNotifications);
    if (!showNotifications && announcements.length > 0) {
      const latestId = announcements[0].id;
      setLastReadId(latestId);
      setHasUnread(false);
      localStorage.setItem('last_read_announcement', latestId);
    }
  };

  return (
    <header className="fixed top-0 left-0 w-full z-[200] flex justify-between items-center px-4 h-16 bg-white/80 backdrop-blur-lg border-b border-slate-200/50 transition-all duration-300 pt-safe">
      <div className="flex items-center gap-3">
        <motion.div 
          whileHover={{ rotate: 10 }}
          className="w-10 h-10 rounded-full overflow-hidden bg-white flex items-center justify-center border border-slate-100 shadow-sm"
        >
          <img 
            src={IMAGES.LOGO} 
            alt="ICC Logo" 
            className="w-full h-full object-cover"
          />
        </motion.div>
        <h1 className="text-primary-container font-semibold text-lg tracking-tight">ICC e-Library</h1>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative">
          <button 
            onClick={handleToggleNotifications}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-slate-100 transition-colors relative group"
          >
            <Bell className={cn("w-5 h-5 transition-colors", hasUnread ? "text-primary" : "text-on-surface-variant")} />
            {hasUnread && (
              <motion.span 
                animate={{ scale: [1, 1.2, 1], opacity: [1, 0.5, 1] }}
                transition={{ repeat: Infinity, duration: 1.5 }}
                className="absolute top-2 right-2 w-2 h-2 bg-error rounded-full border-2 border-white shadow-[0_0_8px_rgba(186,26,26,0.6)]"
              />
            )}
          </button>

          <AnimatePresence>
            {showNotifications && (
              <motion.div
                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.95 }}
                className="absolute right-0 mt-2 w-80 max-h-[400px] bg-white rounded-2xl shadow-2xl border border-outline-variant overflow-hidden z-[300]"
              >
                <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-surface-container-low">
                  <h3 className="text-sm font-black text-primary uppercase tracking-widest">Notifications</h3>
                  <button onClick={() => setShowNotifications(false)}><X size={16} className="text-outline" /></button>
                </div>
                <div className="overflow-y-auto max-h-[320px] divide-y divide-slate-50">
                  {announcements.length > 0 ? (
                    announcements.map((ann: any) => (
                      <div key={ann.id} className="p-4 hover:bg-slate-50 transition-colors">
                        <div className="flex gap-3">
                          <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary shrink-0">
                            <Megaphone size={16} />
                          </div>
                          <div>
                            <h4 className="text-sm font-bold text-on-surface mb-1">{ann.title}</h4>
                            <p className="text-xs text-on-surface-variant line-clamp-2 leading-relaxed">{ann.content}</p>
                            <p className="text-[10px] text-outline font-medium mt-2">{ann.postedBy} • Just now</p>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="p-12 text-center">
                      <CheckCircle2 className="w-8 h-8 text-slate-200 mx-auto mb-2" />
                      <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">No new updates</p>
                    </div>
                  )}
                </div>
                <div className="p-3 bg-slate-50 text-center border-t border-slate-100">
                  <button className="text-[10px] font-black text-primary uppercase tracking-widest hover:underline">View all alerts</button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        
        <div className="flex items-center gap-3 pl-4 border-l border-slate-100">
          <div className="text-right hidden sm:block">
            <p className="text-sm font-semibold text-on-surface">{user.name}</p>
            <p className="text-[10px] uppercase tracking-wider text-outline">{role}</p>
          </div>
          <button className="w-9 h-9 rounded-full overflow-hidden border border-outline-variant">
            <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
          </button>
        </div>
      </div>
    </header>
  );
};

export const BottomNav: React.FC = () => {
  const navItems = [
    { to: '/', icon: LayoutDashboard, label: 'Portal' },
    { to: '/library', icon: Library, label: 'Library' },
    { to: '/chat', icon: MessageSquare, label: 'Groups' },
    { to: '/calendar', icon: Calendar, label: 'Schedule' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 w-full z-[100] flex justify-around items-center h-[72px] bg-white/95 backdrop-blur-md border-t border-slate-200/50 shadow-[0_-8px_30px_rgb(0,0,0,0.04)] pb-safe px-4">
      {navItems.map((item) => (
        <NavLink
          key={item.to}
          to={item.to}
          className={({ isActive }) => cn(
            "flex flex-col items-center justify-center flex-1 transition-all duration-300 relative py-1 px-1",
            isActive ? "text-primary" : "text-slate-400"
          )}
        >
          {({ isActive }) => (
            <>
              <div className={cn(
                "p-1.5 rounded-xl transition-all duration-300",
                isActive ? "bg-primary/5 text-primary" : "hover:bg-slate-50"
              )}>
                <item.icon className={cn("w-6 h-6", isActive ? "stroke-[2.5px]" : "stroke-2")} />
              </div>
              <span className={cn(
                "text-[9px] font-black uppercase tracking-[0.1em] transition-all duration-300 mt-0.5",
                isActive ? "opacity-100 transform translate-y-0" : "opacity-60 transform translate-y-1"
              )}>
                {item.label}
              </span>
              {isActive && (
                <motion.div 
                  layoutId="nav-pill"
                  className="absolute -top-[1px] left-1/2 -translate-x-1/2 w-8 h-1 bg-primary rounded-b-full shadow-[0_2px_10px_rgba(var(--primary),0.3)]"
                />
              )}
            </>
          )}
        </NavLink>
      ))}
    </nav>
  );
};
