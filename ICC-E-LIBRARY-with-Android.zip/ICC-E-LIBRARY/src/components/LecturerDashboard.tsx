import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Upload, 
  Megaphone, 
  ArrowRight, 
  Settings, 
  TrendingUp, 
  MessageCircle,
  FileCheck,
  Search,
  X,
  FileText,
  Download,
  Trash2,
  History,
  Save,
  Send
} from 'lucide-react';
import { BrandingFooter } from './BrandingFooter';
import { IMAGES, MOCK_USERS } from '@/src/constants';
import { cn } from '@/src/lib/utils';
import { db, handleFirestoreError } from '@/src/lib/firebase';
import { 
  collection, 
  addDoc, 
  deleteDoc, 
  doc, 
  onSnapshot, 
  query, 
  where, 
  serverTimestamp 
} from 'firebase/firestore';

interface Material {
  id: string;
  title: string;
  courseId: string;
  courseName: string;
  fileName: string;
  fileUrl: string;
  lecturerId: string;
  createdAt: any;
}

interface LecturerDashboardProps {
  user?: {
    id?: string;
    name?: string;
  } | null;
}

export const LecturerDashboard: React.FC<LecturerDashboardProps> = ({ user: propUser }) => {
  const user = propUser || MOCK_USERS.lecturer;
  const [search, setSearch] = useState('');
  const [materials, setMaterials] = useState<Material[]>([]);
  const [loading, setLoading] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [newMaterial, setNewMaterial] = useState({
    title: '',
    courseName: ''
  });

  const [announcement, setAnnouncement] = useState({ title: '', content: '' });
  const [showAnnouncementModal, setShowAnnouncementModal] = useState(false);

  useEffect(() => {
    // Usually lecturerId should be checked but in this prototype we can use user.name or a fixed lecturerId
    const q = query(collection(db, 'materials'));
    const unsub = onSnapshot(q, (snapshot) => {
      setMaterials(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Material)));
    }, (err) => {
      handleFirestoreError(err, 'get' as any, 'materials');
    });
    return unsub;
  }, []);

  const handlePostAnnouncement = async () => {
    if (!announcement.title || !announcement.content) return;
    setLoading(true);
    try {
      await addDoc(collection(db, 'announcements'), {
        ...announcement,
        postedBy: user.name,
        lecturerId: user.id || 'lecturer-id',
        createdAt: serverTimestamp()
      });
      setShowAnnouncementModal(false);
      setAnnouncement({ title: '', content: '' });
    } catch (err) {
      handleFirestoreError(err, 'create' as any, 'announcements');
    } finally {
      setLoading(false);
    }
  };

  const handleUpload = async () => {
    if (!newMaterial.title || !selectedFile) return;
    setLoading(true);
    try {
      await addDoc(collection(db, 'materials'), {
        title: newMaterial.title,
        courseName: newMaterial.courseName,
        fileName: selectedFile.name,
        fileSize: (selectedFile.size / 1024 / 1024).toFixed(2) + 'MB',
        fileUrl: URL.createObjectURL(selectedFile), // Temporary URL for preview/mock download
        lecturerId: user.id || 'lecturer-id',
        lecturerName: user.name,
        createdAt: serverTimestamp()
      });
      setShowUploadModal(false);
      setNewMaterial({ title: '', courseName: '' });
      setSelectedFile(null);
    } catch (err) {
      handleFirestoreError(err, 'create' as any, 'materials');
    } finally {
      setLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      if (!newMaterial.title) {
        setNewMaterial(prev => ({ ...prev, title: file.name.split('.')[0] }));
      }
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this material?')) return;
    try {
      await deleteDoc(doc(db, 'materials', id));
    } catch (err) {
      handleFirestoreError(err, 'delete' as any, 'materials');
    }
  };

  const courses = [
    { title: 'Advanced Algorithm Design', code: 'CS-402', students: 124, sem: 'SEM 2', img: IMAGES.COURSE_1 },
    { title: 'Network Security & Ethics', code: 'CS-308', students: 89, sem: 'SEM 2', img: IMAGES.COURSE_2 },
  ];

  const filteredCourses = courses.filter(course => 
    course.title.toLowerCase().includes(search.toLowerCase()) || 
    course.code.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-gutter pb-xl text-on-surface">
      <section className="mb-lg">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <span className="text-[10px] font-black text-on-secondary-fixed-variant bg-secondary-fixed px-3 py-1 rounded-full uppercase tracking-widest mb-3 inline-block">Lecturer Portal</span>
            <h2 className="text-4xl font-black text-primary tracking-tight">Welcome back, {user.name}</h2>
            <p className="text-lg text-on-surface-variant max-w-2xl mt-4 font-medium leading-relaxed">
              Manage academic resources, student engagement, and course discussions from your centralized hub.
            </p>
          </div>
          <div className="flex flex-wrap gap-3">
            <button 
              onClick={() => setShowUploadModal(true)}
              className="flex items-center gap-2 bg-primary-container text-white px-6 py-3 rounded-2xl hover:brightness-110 shadow-lg transition-all font-bold group"
            >
              <Upload className="w-5 h-5 group-hover:-translate-y-1 transition-transform" />
              Upload Material
            </button>
            <button 
              onClick={() => setShowAnnouncementModal(true)}
              className="flex items-center gap-2 bg-white border border-outline-variant text-primary px-6 py-3 rounded-2xl hover:bg-slate-50 transition-all font-bold"
            >
              <Megaphone className="w-5 h-5" />
              Post Announcement
            </button>
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-gutter">
        <div className="lg:col-span-8 flex flex-col gap-gutter">
          {/* Courses */}
          <div className="bg-white border border-outline-variant rounded-3xl p-6 shadow-sm">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8 px-2 gap-4">
              <h3 className="text-xl font-black text-primary tracking-tight uppercase">Overview of Courses Taught</h3>
              <div className="flex items-center gap-3 w-full sm:w-auto">
                <div className="relative w-full sm:w-64">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-outline" />
                  <input 
                    type="text" 
                    placeholder="Search your courses..."
                    className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-outline-variant rounded-xl text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none transition-all"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </div>
                <button className="hidden sm:flex text-primary-container font-black text-[10px] uppercase tracking-widest hover:underline items-center gap-1.5 whitespace-nowrap">
                  View All <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {filteredCourses.map((course, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="group bg-surface-container-lowest border border-outline-variant rounded-2xl p-4 hover:border-primary-container transition-all cursor-pointer shadow-sm active:scale-[0.98]"
                >
                  <div className="h-40 rounded-xl bg-slate-100 mb-4 overflow-hidden relative shadow-inner">
                    <img src={course.img} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={course.title} />
                    <div className="absolute top-3 right-3 bg-white/95 backdrop-blur px-2 py-0.5 rounded-lg text-[9px] font-black text-primary border border-slate-100 shadow-sm">{course.sem}</div>
                  </div>
                  <h4 className="text-lg font-bold text-primary mb-1 line-clamp-1">{course.title}</h4>
                  <p className="text-xs text-outline font-bold uppercase tracking-tighter mb-6">{course.code} • {course.students} Students Registered</p>
                  <div className="flex items-center justify-between">
                    <div className="flex -space-x-3">
                      {['JD', 'AK', '+12'].map((init, j) => (
                        <div key={j} className={`w-9 h-9 rounded-full border-2 border-white flex items-center justify-center text-[10px] font-black shadow-sm ${j === 0 ? 'bg-blue-100' : j === 1 ? 'bg-amber-100' : 'bg-emerald-100'}`}>
                          {init}
                        </div>
                      ))}
                    </div>
                    <button className="p-2.5 rounded-xl bg-surface-container-high text-primary hover:bg-primary-container hover:text-white transition-colors shadow-sm">
                      <Settings className="w-5 h-5" />
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="bg-white border border-outline-variant rounded-3xl p-6 shadow-sm">
            <h3 className="text-xl font-black text-primary tracking-tight uppercase mb-8 px-2 flex items-center gap-2">
              <FileText className="w-6 h-6" /> Managed Learning Materials
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {materials.length === 0 ? (
                <div className="col-span-full py-12 text-center border-2 border-dashed border-outline-variant rounded-2xl">
                  <p className="text-sm font-bold text-outline uppercase tracking-widest">No materials uploaded yet</p>
                </div>
              ) : (
                materials.map((mat, i) => (
                  <motion.div 
                    key={mat.id}
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="p-4 bg-slate-50 border border-outline-variant rounded-2xl flex flex-col gap-3 group hover:border-primary transition-all"
                  >
                    <div className="flex items-start justify-between">
                      <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-colors">
                        <FileText className="w-5 h-5" />
                      </div>
                      <div className="flex items-center gap-1">
                        <a 
                          href={mat.fileUrl} 
                          download={mat.fileName}
                          className="p-2 text-outline-variant hover:text-primary transition-colors"
                        >
                          <Download className="w-4 h-4" />
                        </a>
                        <button 
                          onClick={() => handleDelete(mat.id)}
                          className="p-2 text-outline-variant hover:text-error transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                    <div>
                      <h5 className="font-bold text-on-surface line-clamp-1">{mat.title}</h5>
                      <p className="text-[10px] font-black text-outline uppercase tracking-widest">{mat.courseName || 'General Resource'}</p>
                    </div>
                    <div className="pt-2 border-t border-outline-variant flex justify-between items-center text-[9px] font-black text-outline uppercase tracking-tight">
                      <span>{mat.fileName}</span>
                      <span>{mat.createdAt?.toDate().toLocaleDateString() || 'Just now'}</span>
                    </div>
                  </motion.div>
                ))
              )}
            </div>
          </div>
        </div>

        <div className="lg:col-span-4 flex flex-col gap-gutter">
           {/* Upload Info Stats */}
          <div className="bg-primary-container text-white border border-outline-variant rounded-3xl p-6 shadow-xl relative overflow-hidden">
            <div className="relative z-10">
              <h3 className="text-xs font-black uppercase tracking-widest mb-6 px-2 opacity-80">Quick Stats</h3>
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-3xl font-black">{materials.length}</div>
                    <div className="text-[10px] font-bold uppercase opacity-70">Active Resources</div>
                  </div>
                  <FileText className="w-8 h-8 opacity-20" />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-3xl font-black">1.2k</div>
                    <div className="text-[10px] font-bold uppercase opacity-70">Total Downloads</div>
                  </div>
                  <Download className="w-8 h-8 opacity-20" />
                </div>
              </div>
            </div>
            <div className="absolute right-[-20%] bottom-[-20%] w-48 h-48 bg-white/10 rounded-full blur-3xl" />
          </div>

           {/* Feedback/Activity */}
           <div className="bg-white border border-outline-variant rounded-3xl p-6 shadow-sm overflow-hidden flex-1">
            <h3 className="text-xs font-black text-outline uppercase tracking-widest mb-8 px-2">Access Logs</h3>
            <ul className="space-y-6">
              {materials.slice(0, 5).map((mat, i) => (
                <li key={i} className="flex gap-4 group cursor-pointer p-2 hover:bg-slate-50 rounded-xl transition-colors">
                  <div className={cn("mt-2 w-2 h-2 rounded-full shrink-0 shadow-sm bg-primary")} />
                  <div>
                    <p className="text-sm font-bold text-primary leading-tight group-hover:text-primary-container transition-colors tracking-tight">
                      Uploaded resource: {mat.title}
                    </p>
                    <span className="text-[10px] font-black text-outline uppercase mt-1 inline-block">Sync Complete</span>
                  </div>
                </li>
              ))}
              {materials.length === 0 && (
                <li className="text-center py-8">
                  <p className="text-[10px] font-black text-outline uppercase">Awaiting activity...</p>
                </li>
              )}
            </ul>
          </div>
        </div>
      </div>

      {/* Upload Modal */}
      <AnimatePresence>
        {showUploadModal && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowUploadModal(false)}
              className="absolute inset-0 bg-on-surface/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, y: 20, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.9, y: 20, opacity: 0 }}
              className="relative bg-white w-full max-w-md rounded-3xl p-8 shadow-2xl border border-outline-variant"
            >
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-xl font-black text-primary tracking-tighter uppercase">Provision Learning Node</h3>
                <button onClick={() => setShowUploadModal(false)} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Material Title</label>
                  <input 
                    type="text" 
                    className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-bold outline-none focus:border-primary transition-all"
                    placeholder="e.g. Week 4: Neural Networks"
                    value={newMaterial.title}
                    onChange={(e) => setNewMaterial({...newMaterial, title: e.target.value})}
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Course Node</label>
                  <input 
                    type="text" 
                    className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-bold outline-none focus:border-primary transition-all"
                    placeholder="e.g. CS-402 Advanced AI"
                    value={newMaterial.courseName}
                    onChange={(e) => setNewMaterial({...newMaterial, courseName: e.target.value})}
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Source Material Node</label>
                  <input 
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    className="hidden"
                  />
                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full p-8 border-2 border-dashed border-outline-variant rounded-2xl flex flex-col items-center justify-center gap-3 hover:border-primary hover:bg-primary/5 transition-all group"
                  >
                    <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-outline group-hover:bg-primary group-hover:text-white transition-all">
                      <Upload className="w-6 h-6" />
                    </div>
                    {selectedFile ? (
                      <div className="text-center">
                        <p className="text-sm font-black text-primary uppercase tracking-tight">{selectedFile.name}</p>
                        <p className="text-[10px] font-bold text-outline uppercase tracking-widest">{(selectedFile.size / 1024).toFixed(1)} KB • Ready for Sync</p>
                      </div>
                    ) : (
                      <div className="text-center">
                        <p className="text-xs font-black text-on-surface uppercase tracking-widest">Access Local Folders</p>
                        <p className="text-[9px] font-bold text-outline uppercase tracking-tight">PDF, DOCX, PPTX supported</p>
                      </div>
                    )}
                  </button>
                </div>

                <div className="pt-4">
                  <button 
                    onClick={handleUpload}
                    disabled={loading || !newMaterial.title || !selectedFile}
                    className="w-full bg-primary text-white py-4 rounded-2xl font-black uppercase tracking-widest shadow-xl hover:bg-primary-container active:scale-[0.98] disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                  >
                    {loading ? <History className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                    Broadcast Material
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      
      {/* Announcement Modal */}
      <AnimatePresence>
        {showAnnouncementModal && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAnnouncementModal(false)}
              className="absolute inset-0 bg-on-surface/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, y: 20, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.9, y: 20, opacity: 0 }}
              className="relative bg-white w-full max-w-md rounded-3xl p-8 shadow-2xl border border-outline-variant"
            >
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-xl font-black text-primary tracking-tighter uppercase">Broadcast Announcement</h3>
                <button onClick={() => setShowAnnouncementModal(false)} className="p-2 hover:bg-slate-100 rounded-full">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Announcement Title</label>
                  <input 
                    type="text" 
                    className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-bold outline-none focus:border-primary transition-all"
                    placeholder="e.g. Class Reschedule Alert"
                    value={announcement.title}
                    onChange={(e) => setAnnouncement({...announcement, title: e.target.value})}
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Message Content</label>
                  <textarea 
                    rows={4}
                    className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-medium outline-none focus:border-primary transition-all resize-none"
                    placeholder="Compose your message to all students..."
                    value={announcement.content}
                    onChange={(e) => setAnnouncement({...announcement, content: e.target.value})}
                  />
                </div>

                <div className="pt-4">
                  <button 
                    onClick={handlePostAnnouncement}
                    disabled={loading || !announcement.title || !announcement.content}
                    className="w-full bg-primary text-white py-4 rounded-2xl font-black uppercase tracking-widest shadow-xl hover:bg-primary-container active:scale-[0.98] disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                  >
                    {loading ? <History className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
                    Broadcast Message
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <BrandingFooter />
    </div>
  );
};
