import React from 'react';
import { 
  Calendar as CalendarIcon, 
  ChevronLeft, 
  ChevronRight, 
  FileSignature, 
  BarChart3, 
  PartyPopper,
  Info,
  Clock
} from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '@/src/lib/utils';
import { BrandingFooter } from './BrandingFooter';

export const CalendarPage: React.FC = () => {
  const days = Array.from({ length: 31 }, (_, i) => i + 1);
  const events = [
    { date: 16, month: 'Oct', title: 'Algorithms Assignment II', sub: 'Submission Portal Closes', type: 'deadline', icon: FileSignature, status: 'Deadline', time: '11:59 PM', color: 'text-error bg-error/10 border-error' },
    { date: 20, month: 'Oct', title: 'Mid-Term Examination Week', sub: 'Core Engineering Subjects', type: 'academic', icon: BarChart3, status: 'Academic', time: '5 Days Duration', color: 'text-primary bg-primary/10 border-primary' },
    { date: 1, month: 'Nov', title: 'Foundation Day', sub: 'Campus Holiday - No Classes', type: 'holiday', icon: PartyPopper, status: 'Holiday', time: 'Full Day', color: 'text-secondary bg-secondary/10 border-secondary' },
  ];

  return (
    <div className="max-w-screen-md mx-auto space-y-gutter pb-xl">
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-bold text-on-surface tracking-tight">Academic Calendar</h1>
        <div className="flex items-center justify-between mt-2">
          <div className="flex items-center gap-2 text-primary-container font-semibold text-sm">
            <CalendarIcon className="w-4 h-4" />
            <span>Fall Semester 2024</span>
          </div>
          <button className="text-xs font-bold text-outline border border-outline-variant px-3 py-1.5 rounded-full hover:bg-white transition-colors">
            Switch Semester
          </button>
        </div>
      </div>

      {/* Monthly View */}
      <section className="bg-white rounded-2xl border border-outline-variant p-md shadow-sm overflow-hidden">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-xl font-bold text-on-surface">October 2024</h2>
          <div className="flex gap-2">
            <button className="p-2 rounded-xl border border-outline-variant hover:bg-surface-container-low transition-colors"><ChevronLeft className="w-5 h-5" /></button>
            <button className="p-2 rounded-xl border border-outline-variant hover:bg-surface-container-low transition-colors"><ChevronRight className="w-5 h-5" /></button>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-y-6 text-center">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
            <div key={day} className="text-[10px] font-black text-outline uppercase tracking-widest">{day}</div>
          ))}
          {/* Padding for month start */}
          <div className="text-outline-variant font-medium text-sm py-2">29</div>
          <div className="text-outline-variant font-medium text-sm py-2">30</div>
          
          {days.map(d => {
            const isToday = d === 9;
            const hasHoliday = [2, 11, 12, 1].includes(d);
            const hasExam = [16, 20, 21, 22, 23, 24].includes(d);
            
            return (
              <div key={d} className="relative group cursor-pointer flex flex-col items-center">
                <div className={cn(
                  "w-9 h-9 flex items-center justify-center rounded-xl text-sm font-bold transition-all relative z-10",
                  isToday ? "bg-primary-container text-white shadow-md ring-4 ring-blue-50" : 
                  hasHoliday ? "bg-secondary-container/20 text-on-secondary-container" :
                  hasExam ? "bg-error-container/20 text-on-error-container" : "text-on-surface hover:bg-surface-container-low"
                )}>
                  {d}
                </div>
                {/* Dots */}
                <div className="flex gap-0.5 mt-1">
                  {hasHoliday && <div className="w-1 h-1 rounded-full bg-secondary" />}
                  {hasExam && <div className="w-1 h-1 rounded-full bg-error" />}
                  {hasHoliday && d === 2 && <div className="w-1 h-1 rounded-full bg-primary" />}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Events List */}
      <section className="space-y-4">
        <h3 className="text-lg font-bold text-on-surface px-2">Upcoming Events</h3>
        {events.map((event, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
            className="flex items-start gap-4 p-4 bg-white border border-outline-variant rounded-2xl hover:shadow-md transition-shadow group"
          >
            <div className={cn(
              "flex flex-col items-center justify-center min-w-[56px] h-14 rounded-xl border transition-colors",
              event.color
            )}>
              <span className="text-[10px] font-black uppercase tracking-widest leading-none">{event.month}</span>
              <span className="text-xl font-black">{event.date}</span>
            </div>
            <div className="flex-1">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="font-bold text-on-surface group-hover:text-primary transition-colors">{event.title}</h4>
                  <p className="text-xs text-on-surface-variant font-medium mt-0.5">{event.sub}</p>
                </div>
                <event.icon className="w-5 h-5 text-on-surface-variant group-hover:text-primary transition-colors" />
              </div>
              <div className="mt-3 flex items-center gap-3">
                <span className={cn("px-2 py-1 rounded-lg text-[9px] font-black uppercase tracking-wider", event.color.split(' ').slice(0,2).join(' '))}>
                  {event.status}
                </span>
                <span className="text-xs font-bold text-outline flex items-center gap-1">
                  <Clock className="w-3 h-3" /> {event.time}
                </span>
              </div>
            </div>
          </motion.div>
        ))}
      </section>

      {/* Guidelines Section */}
      <section className="bg-primary-container p-6 rounded-2xl text-white relative overflow-hidden shadow-lg border border-primary">
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-4">
            <Info className="w-6 h-6 text-secondary-container" />
            <h4 className="font-bold text-lg">Academic Reminders</h4>
          </div>
          <ul className="space-y-3">
            <li className="flex items-start gap-3 text-sm text-on-primary-container leading-relaxed">
              <div className="w-1.5 h-1.5 rounded-full bg-secondary-container mt-1.5 shrink-0" />
              Ensure all lab reports are peer-reviewed before official portal submission.
            </li>
            <li className="flex items-start gap-3 text-sm text-on-primary-container leading-relaxed">
              <div className="w-1.5 h-1.5 rounded-full bg-secondary-container mt-1.5 shrink-0" />
              Library hours extended to 24/7 during physical examination periods.
            </li>
          </ul>
        </div>
        <div className="absolute -right-8 -bottom-8 opacity-10 rotate-12">
          <CalendarIcon size={160} />
        </div>
      </section>

      <BrandingFooter />
    </div>
  );
};
