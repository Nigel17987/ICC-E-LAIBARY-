import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  ArrowRight, 
  Download, 
  Search, 
  Filter, 
  Heart,
  MessageSquare,
  ChevronRight,
  BookMarked,
  Plus,
  BookOpen,
  X,
  CheckCircle,
  Loader2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { IMAGES, UserRole } from '@/src/constants';
import { cn } from '@/src/lib/utils';
import { BrandingFooter } from './BrandingFooter';
import { collection, addDoc, query, onSnapshot, orderBy, Timestamp } from 'firebase/firestore';
import { db } from '@/src/lib/firebase';

export const LibraryPage: React.FC = () => {
  const [search, setSearch] = useState('');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [materials, setMaterials] = useState<any[]>([]);
  const [newBook, setNewBook] = useState({ title: '', author: '' });

  // Listen to materials (including e-books)
  useEffect(() => {
    const q = query(collection(db, 'materials'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setMaterials(docs);
    });
    return () => unsub();
  }, []);

  const resources = [
    { title: 'Introduction to DOM Manipulation', size: '2.4 MB', type: 'PDF', icon: FileText, color: 'bg-red-50 text-red-600', liked: false },
    { title: 'React State Management Best Practices', size: '15 KB', type: 'Notes', icon: BookMarked, color: 'bg-blue-50 text-blue-600', liked: true },
    ...materials.map(m => ({
      title: m.title,
      size: m.size || 'Unknown',
      type: m.type || 'E-book',
      icon: m.type === 'E-book' ? BookOpen : FileText,
      color: m.type === 'E-book' ? 'bg-purple-50 text-purple-600' : 'bg-slate-50 text-slate-600',
      liked: false
    }))
  ];

  const filteredResources = resources.filter(res => 
    res.title.toLowerCase().includes(search.toLowerCase()) ||
    res.type.toLowerCase().includes(search.toLowerCase())
  );

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBook.title) return;

    setIsUploading(true);
    try {
      await addDoc(collection(db, 'materials'), {
        title: newBook.title,
        type: 'E-book',
        author: newBook.author || 'Internal Library',
        createdAt: Timestamp.now(),
        size: 'N/A',
        fileUrl: '#'
      });
      setUploadSuccess(true);
      setTimeout(() => {
        setUploadSuccess(false);
        setShowUploadModal(false);
        setNewBook({ title: '', author: '' });
      }, 2000);
    } catch (error) {
      console.error("Upload error:", error);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="space-y-gutter pb-xl">
      {/* Search & Breadcrumbs */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <nav className="flex items-center gap-2 text-xs font-bold text-outline">
          <a href="#" className="hover:text-primary">Library</a>
          <ChevronRight className="w-3 h-3" />
          <a href="#" className="hover:text-primary">Computer Science</a>
          <ChevronRight className="w-3 h-3" />
          <span className="text-on-surface">Digital Repository</span>
        </nav>
        
        <button 
          onClick={() => setShowUploadModal(true)}
          className="bg-primary text-white px-5 py-2.5 rounded-full font-black text-xs uppercase tracking-widest flex items-center gap-2 shadow-lg hover:brightness-110 active:scale-95 transition-all w-fit"
        >
          <Plus size={16} />
          Upload E-book
        </button>
      </div>

      <section className="flex flex-col lg:flex-row lg:items-end justify-between gap-md mb-md">
        <div className="max-w-2xl">
          <h2 className="text-3xl font-black text-primary tracking-tight mb-2 uppercase italic overflow-hidden">
            <motion.span 
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              className="inline-block"
            >
              ICC e-Library
            </motion.span>
          </h2>
          <p className="text-on-surface-variant leading-relaxed text-sm">
            Access our specialized collection of E-books and academic materials. The portal is dedicated to high-quality digital resources for students and lecturers.
          </p>
        </div>
        <div className="relative w-full lg:w-96 shadow-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-outline" />
          <input 
            type="text" 
            placeholder="Search E-books & Resources..."
            className="w-full pl-10 pr-4 py-3 bg-white border border-outline-variant rounded-xl focus:ring-2 focus:ring-primary focus:border-primary outline-none transition-all"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </section>

      {/* Upload Modal */}
      <AnimatePresence>
        {showUploadModal && (
          <div className="fixed inset-0 z-[500] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowUploadModal(false)}
              className="absolute inset-0 bg-primary/40 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl overflow-hidden border border-outline-variant"
            >
              <div className="p-8">
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h3 className="text-2xl font-black text-primary uppercase italic">Upload E-book</h3>
                    <p className="text-xs font-bold text-outline uppercase tracking-widest mt-1">Digital Repository Only</p>
                  </div>
                  <button onClick={() => setShowUploadModal(false)} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                    <X size={20} className="text-outline" />
                  </button>
                </div>

                {uploadSuccess ? (
                  <div className="py-12 flex flex-col items-center text-center">
                    <div className="w-16 h-16 bg-green-50 text-green-600 rounded-full flex items-center justify-center mb-4">
                      <CheckCircle size={32} />
                    </div>
                    <h4 className="text-lg font-bold text-primary">Catalog Updated!</h4>
                    <p className="text-sm text-outline">The e-book has been added to the library.</p>
                  </div>
                ) : (
                  <form onSubmit={handleUpload} className="space-y-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-primary uppercase tracking-widest ml-1">Book Title</label>
                      <input 
                        required
                        type="text" 
                        placeholder="e.g. Clean Code: A Handbook..."
                        className="w-full px-4 py-3 rounded-2xl bg-slate-50 border border-outline-variant focus:bg-white focus:ring-2 focus:ring-primary transition-all outline-none"
                        value={newBook.title}
                        onChange={e => setNewBook({...newBook, title: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-primary uppercase tracking-widest ml-1">Author Name</label>
                      <input 
                        type="text" 
                        placeholder="e.g. Robert C. Martin"
                        className="w-full px-4 py-3 rounded-2xl bg-slate-50 border border-outline-variant focus:bg-white focus:ring-2 focus:ring-primary transition-all outline-none"
                        value={newBook.author}
                        onChange={e => setNewBook({...newBook, author: e.target.value})}
                      />
                    </div>
                    <div className="p-6 border-2 border-dashed border-outline-variant rounded-3xl bg-slate-50/50 flex flex-col items-center text-center group hover:border-primary transition-colors cursor-pointer">
                      <div className="w-12 h-12 bg-white rounded-2xl shadow-sm flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                        <BookOpen className="text-primary" />
                      </div>
                      <p className="text-xs font-bold text-on-surface uppercase tracking-tight">Select E-book File</p>
                      <p className="text-[10px] text-outline mt-1 font-medium">EPUB, MOBI or AZW3 formats only</p>
                      <input type="file" className="hidden" accept=".epub,.mobi,.azw3" />
                    </div>
                    
                    <button 
                      disabled={isUploading}
                      type="submit"
                      className="w-full py-4 bg-primary text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-primary/20 hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                    >
                      {isUploading ? <Loader2 className="animate-spin" /> : <Plus size={18} />}
                      Add to E-Book Shelf
                    </button>
                    <p className="text-[9px] text-center text-outline font-medium px-4">
                      By publishing, you confirm this material adheres to the ICC academic integrity guidelines for digital course materials.
                    </p>
                  </form>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Featured Header */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        className="grid grid-cols-1 md:grid-cols-12 gap-gutter"
      >
        <div className="md:col-span-8 bg-surface-container-low rounded-2xl border border-outline-variant overflow-hidden group shadow-sm flex flex-col md:flex-row h-full">
          <div className="md:w-1/3 relative h-48 md:h-auto overflow-hidden">
            <img 
              src={IMAGES.LIBRARY_HERO} 
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
              alt="Course Material" 
            />
            <div className="absolute inset-0 bg-gradient-to-t from-primary/80 to-transparent flex flex-col justify-end p-4">
              <span className="text-[10px] font-black bg-secondary-container text-on-secondary-container px-2 py-0.5 rounded w-fit mb-1">Updated</span>
              <p className="text-white text-xs font-bold">2 days ago</p>
            </div>
          </div>
          <div className="md:w-2/3 p-md flex flex-col justify-between">
            <div>
              <h3 className="text-2xl font-bold text-primary mb-2">Final Project Specification v2.0</h3>
              <p className="text-on-surface-variant leading-relaxed mb-6">Complete breakdown of requirements for the full-stack web application capstone project including architecture and documentation standards.</p>
            </div>
            <div className="flex items-center gap-3">
              <button className="flex items-center gap-2 bg-primary text-white px-6 py-2.5 rounded-xl font-bold hover:brightness-110 transition-all shadow-md">
                <Download className="w-4 h-4" /> Download PDF
              </button>
              <button className="w-10 h-10 flex items-center justify-center rounded-xl border border-outline-variant hover:bg-white transition-colors group">
                <Heart className="w-5 h-5 text-outline group-hover:text-error transition-colors" />
              </button>
            </div>
          </div>
        </div>

        <div className="md:col-span-4 bg-white border border-outline-variant rounded-2xl p-md flex flex-col justify-between shadow-sm">
          <div>
            <h4 className="text-[10px] font-black text-outline bg-surface-container px-3 py-1 -mx-md -mt-md mb-md uppercase tracking-widest">Course Stats</h4>
            <div className="space-y-4">
              <div className="flex items-center justify-between group cursor-pointer">
                <span className="text-sm font-semibold group-hover:text-primary transition-colors">Lecture Notes</span>
                <span className="bg-surface-container-high px-2 py-0.5 rounded-lg text-xs font-bold">14 Files</span>
              </div>
              <div className="flex items-center justify-between group cursor-pointer text-error underline decoration-2 underline-offset-4">
                <span className="text-sm font-semibold">Assignments</span>
                <span className="bg-error-container text-on-error-container px-2 py-0.5 rounded-lg text-xs font-bold">4 Due</span>
              </div>
              <div className="flex items-center justify-between group cursor-pointer">
                <span className="text-sm font-semibold group-hover:text-primary transition-colors">Reference Books</span>
                <span className="bg-surface-container-high px-2 py-0.5 rounded-lg text-xs font-bold">3 Restricted</span>
              </div>
            </div>
          </div>
          <button className="mt-8 w-full py-3 rounded-xl border-2 border-primary text-primary font-bold text-sm hover:bg-primary-container hover:text-white hover:border-primary-container transition-all flex items-center justify-center gap-2">
            Request Additional Material
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </motion.div>

      {/* Resource List */}
      <section className="mt-8">
        <div className="flex items-center gap-2 mb-6">
          <Filter className="w-4 h-4 text-outline" />
          <h3 className="text-lg font-bold text-primary">All Resources</h3>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-gutter">
          {filteredResources.map((res, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-white p-md rounded-2xl border border-outline-variant hover:shadow-md transition-all flex flex-col justify-between group cursor-pointer active:scale-[0.98]"
            >
              <div className="flex gap-4 mb-4">
                <div className={`w-12 h-12 rounded-xl ${res.color} flex items-center justify-center shrink-0`}>
                  <res.icon className="w-6 h-6" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-bold text-on-surface leading-tight truncate group-hover:text-primary transition-colors">{res.title}</h4>
                    {res.type === 'E-book' && (
                       <span className="text-[8px] font-black bg-purple-100 text-purple-700 px-1.5 py-0.5 rounded uppercase tracking-tighter shrink-0 border border-purple-200">E-Book</span>
                    )}
                  </div>
                  <p className="text-xs text-outline font-medium">{res.size} • {res.type}</p>
                </div>
              </div>
              <div className="flex items-center justify-between pt-4 border-t border-slate-50">
                <button className="text-primary-container font-black text-xs flex items-center gap-1.5 uppercase hover:brightness-75">
                  <Download className="w-3.5 h-3.5" /> Download
                </button>
                <Heart className={cn("w-5 h-5 cursor-pointer transition-colors", res.liked ? "fill-orange-400 text-orange-400" : "text-outline hover:text-red-400")} />
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Community Section */}
      <section className="bg-white border border-outline-variant rounded-2xl p-gutter mt-lg shadow-sm">
        <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-primary-container" />
          Course Discussion
        </h3>
        <div className="flex gap-4 mb-8">
          <img className="w-10 h-10 rounded-full border border-outline-variant" src={IMAGES.STUDENT_AVATAR} alt="User" />
          <div className="flex-1">
            <textarea 
              className="w-full p-4 bg-surface-container-low border border-outline-variant rounded-2xl focus:ring-2 focus:ring-primary focus:border-primary transition-all outline-none text-sm resize-none" 
              placeholder="Ask a question about these materials..."
              rows={2}
            />
            <div className="flex justify-end mt-2">
              <button className="bg-primary text-white px-6 py-2 rounded-xl font-bold text-sm shadow-sm hover:brightness-110">Post Question</button>
            </div>
          </div>
        </div>
      </section>

      <BrandingFooter />
    </div>
  );
};
