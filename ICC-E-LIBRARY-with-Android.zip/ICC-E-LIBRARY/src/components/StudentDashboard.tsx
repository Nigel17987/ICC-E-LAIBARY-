import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Megaphone, 
  PlayCircle, 
  Terminal, 
  Database, 
  ShieldCheck, 
  ChevronRight,
  Clock,
  BookOpen,
  Search,
  FileText,
  Download
} from 'lucide-react';
import { BrandingFooter } from './BrandingFooter';
import { IMAGES, MOCK_USERS } from '@/src/constants';
import { db, handleFirestoreError } from '@/src/lib/firebase';
import { 
  collection, 
  onSnapshot, 
  query, 
  orderBy,
  limit 
} from 'firebase/firestore';

interface Material {
  id: string;
  title: string;
  courseName: string;
  fileName: string;
  fileUrl: string;
  createdAt: any;
}

interface StudentDashboardProps {
  user?: {
    name?: string;
  } | null;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({ user: propUser }) => {
  const user = propUser || MOCK_USERS.student;
  const [search, setSearch] = useState('');
  const [materials, setMaterials] = useState<Material[]>([]);

  useEffect(() => {
    const q = query(collection(db, 'materials'), orderBy('createdAt', 'desc'), limit(10));
    const unsub = onSnapshot(q, (snapshot) => {
      setMaterials(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Material)));
    }, (err) => {
      // Background error handling
      console.warn("Material sync restricted:", err.message);
    });
    return unsub;
  }, []);

  const courses = [
    { title: 'Advanced Web Architecture', code: 'CS-402', prof: 'Sarah Mitchell', progress: 75, icon: Terminal, color: 'bg-primary-container' },
    { title: 'Cloud Database Management', code: 'CS-308', prof: 'Robert Chen', progress: 42, icon: Database, color: 'bg-secondary-container' },
    { title: 'Cybersecurity Foundations', code: 'CS-210', prof: 'James Wilson', progress: 12, icon: ShieldCheck, color: 'bg-tertiary-container' },
  ];

  const filteredCourses = courses.filter(course => 
    course.title.toLowerCase().includes(search.toLowerCase()) || 
    course.code.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-gutter">
      {/* Hero Welcome */}
      <motion.section 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-2xl bg-primary-container p-gutter sm:p-lg text-white shadow-lg"
      >
        <div className="relative z-10 max-w-2xl">
          <span className="text-xs font-bold uppercase tracking-widest text-secondary-container mb-2 block">Welcome Back</span>
          <h2 className="text-3xl sm:text-4xl font-bold mb-4 uppercase tracking-tighter">Hello, {user.name}</h2>
          <p className="text-lg text-on-primary-container mb-6 opacity-90 leading-relaxed font-black uppercase tracking-tight">
            Your academic progress is on track. You have <span className="text-white underline decoration-secondary-container">{materials.length} new resources</span> available to download.
          </p>
          <button 
            onClick={() => window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' })}
            className="bg-secondary-container text-on-secondary-container px-6 py-3 rounded-xl font-black text-xs uppercase tracking-widest hover:brightness-110 transition-all flex items-center gap-2 shadow-sm group"
          >
            <Download className="w-5 h-5 group-hover:translate-y-1 transition-transform" />
            Examine Latest Resources
          </button>
        </div>
        <div className="absolute right-[-10%] top-[-20%] w-96 h-96 bg-tertiary-container rounded-full opacity-30 blur-3xl" />
        <div className="absolute right-[10%] bottom-[-10%] w-64 h-64 bg-secondary-container rounded-full opacity-10 blur-2xl" />
      </motion.section>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-gutter">
        {/* Left Column */}
        <div className="lg:col-span-8 space-y-gutter">
          {/* Courses */}
          <div className="bg-white border border-outline-variant rounded-2xl p-md shadow-sm">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6 px-2">
              <h3 className="text-xl font-bold text-primary uppercase tracking-tight">My Registered Modules</h3>
              <div className="flex items-center gap-3 w-full sm:w-auto">
                <div className="relative w-full sm:w-64">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-outline" />
                  <input 
                    type="text" 
                    placeholder="Filter courses..."
                    className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-outline-variant rounded-xl text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none transition-all"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </div>
              </div>
            </div>
            <div className="space-y-6">
              {filteredCourses.map((course, i) => (
                <motion.div 
                  key={course.code}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="group cursor-pointer hover:bg-surface-container-low p-2 rounded-xl transition-colors"
                >
                  <div className="flex items-center gap-4 mb-3">
                    <div className={`w-12 h-12 rounded-xl ${course.color} flex items-center justify-center text-white shadow-sm`}>
                      <course.icon className="w-6 h-6" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-bold text-on-surface truncate uppercase tracking-tight">{course.title}</h4>
                      <p className="text-xs text-on-surface-variant font-black uppercase tracking-widest">{course.code} • Professor {course.prof}</p>
                    </div>
                    <div className="text-right">
                      <span className="text-sm font-black text-on-surface uppercase tracking-widest">{course.progress}%</span>
                    </div>
                  </div>
                  <div className="w-full bg-surface-container h-2 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${course.progress}%` }}
                      transition={{ duration: 1, ease: 'easeOut' }}
                      className={`${course.color} h-full rounded-full`}
                    />
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Academic Resources List */}
          <div className="bg-white border border-outline-variant rounded-2xl p-md shadow-sm">
            <div className="flex items-center gap-2 mb-6 px-2">
              <FileText className="text-primary w-5 h-5" />
              <h3 className="text-xl font-bold text-primary uppercase tracking-tight">Available Learning Materials</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {materials.length === 0 ? (
                <div className="col-span-full py-12 text-center bg-slate-50 border border-dashed border-outline-variant rounded-xl">
                  <p className="text-xs font-black text-outline uppercase tracking-[0.2em]">Synchronizing academic data...</p>
                </div>
              ) : (
                materials.map((mat, i) => (
                  <motion.div 
                    key={mat.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-4 bg-white border border-outline-variant rounded-xl flex items-center gap-4 group hover:border-primary transition-all shadow-sm"
                  >
                    <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center text-primary shrink-0 transition-colors group-hover:bg-primary group-hover:text-white">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h5 className="text-xs font-black uppercase text-on-surface truncate mb-0.5 tracking-tight">{mat.title}</h5>
                      <span className="text-[9px] font-black uppercase text-outline tracking-widest">{mat.courseName || 'Public Node'}</span>
                    </div>
                    <a 
                      href={mat.fileUrl} 
                      download={mat.fileName}
                      className="p-2 bg-slate-50 rounded-lg text-primary hover:bg-primary hover:text-white transition-all"
                    >
                      <Download className="w-4 h-4" />
                    </a>
                  </motion.div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Right Column */}
        <div className="lg:col-span-4 space-y-gutter">
          {/* Calendar Promo */}
          <div className="bg-white border border-outline-variant rounded-2xl p-md shadow-sm">
            <h3 className="text-xs font-black text-on-surface-variant uppercase tracking-[0.2em] mb-6 px-2">Critical Deadlines</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3 p-2 hover:bg-red-50/50 rounded-lg transition-colors group cursor-pointer">
                <div className="mt-1.5 w-2 h-2 rounded-full bg-error group-hover:scale-125 transition-transform" />
                <div>
                  <p className="font-bold text-on-surface uppercase text-xs tracking-tight">Web Architecture Project</p>
                  <p className="text-[10px] text-error font-black uppercase tracking-widest mt-1">Due Today, 11:59 PM</p>
                </div>
              </li>
              <li className="flex items-start gap-3 p-2 hover:bg-amber-50/50 rounded-lg transition-colors group cursor-pointer">
                <div className="mt-1.5 w-2 h-2 rounded-full bg-secondary group-hover:scale-125 transition-transform" />
                <div>
                  <p className="font-bold text-on-surface uppercase text-xs tracking-tight">Database Infrastructure Quiz</p>
                  <p className="text-[10px] text-on-surface-variant font-black uppercase tracking-widest mt-1">Due Oct 24, 10:00 AM</p>
                </div>
              </li>
            </ul>
          </div>
          
          {/* Featured Recommendation */}
          <div className="bg-white border border-outline-variant rounded-2xl overflow-hidden shadow-sm group">
            <div className="relative h-40 overflow-hidden">
              <img 
                src={IMAGES.RECOMMENDATION} 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                alt="New in Library" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/80 to-transparent" />
              <div className="absolute top-3 left-3 bg-secondary-container px-2 py-0.5 rounded text-[10px] font-black text-on-secondary-container uppercase">System Highlight</div>
            </div>
            <div className="p-md bg-white text-center">
              <h4 className="font-black text-on-surface mb-2 uppercase tracking-tight">Modern Stack Implementation</h4>
              <p className="text-[10px] text-on-surface-variant leading-relaxed line-clamp-2 font-bold uppercase tracking-tight">Master advanced cloud patterns and edge computation from the ICC resource nodes.</p>
            </div>
          </div>
        </div>
      </div>

      <BrandingFooter />
    </div>
  );
};
