import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  FileText, 
  Upload, 
  Download, 
  Clock, 
  CheckCircle2, 
  AlertCircle,
  FileUp,
  Plus,
  X,
  BookOpen,
  User,
  History,
  FileCode,
  Loader2,
  Save,
  Trash2
} from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { db, handleFirestoreError, auth } from '@/src/lib/firebase';
import { 
  collection, 
  addDoc, 
  onSnapshot, 
  query, 
  where, 
  serverTimestamp,
  doc,
  deleteDoc,
  updateDoc
} from 'firebase/firestore';
import { UserRole } from '@/src/constants';
import { BrandingFooter } from './BrandingFooter';

interface Assignment {
  id: string;
  title: string;
  courseId: string;
  courseName?: string;
  dueDate: string;
  type: 'task' | 'submission';
  studentId?: string;
  studentName?: string;
  fileName: string;
  fileUrl: string;
  status: 'pending' | 'submitted' | 'graded';
}

export const AssignmentsPage: React.FC<{ role: UserRole, user: any }> = ({ role, user }) => {
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [courses, setCourses] = useState<any[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [loading, setLoading] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const submissionInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [targetTask, setTargetTask] = useState<Assignment | null>(null);
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const [newAssignment, setNewAssignment] = useState({
    title: '',
    courseId: '',
    dueDate: ''
  });

  const [gradingAssignment, setGradingAssignment] = useState<Assignment | null>(null);
  const [grade, setGrade] = useState('');
  const [comment, setComment] = useState('');

  useEffect(() => {
    // Load courses for selection
    const unsubCourses = onSnapshot(collection(db, 'courses'), (snap) => {
      setCourses(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });

    // Load assignments based on role
    // Using simple collection listen for now to avoid complex query indexes during dev
    const unsubAssignments = onSnapshot(collection(db, 'assignments'), (snap) => {
      setAssignments(snap.docs.map(d => ({ id: d.id, ...d.data() } as Assignment)));
    });

    return () => {
      unsubCourses();
      unsubAssignments();
    };
  }, []);

  const handleGradeSubmission = async () => {
    if (!gradingAssignment || !grade) return;
    setLoading(true);
    try {
      await updateDoc(doc(db, 'assignments', gradingAssignment.id), {
        status: 'graded',
        grade: grade,
        comment: comment,
        gradedAt: serverTimestamp(),
        gradedBy: user?.name || 'Lecturer'
      });
      setGradingAssignment(null);
      setGrade('');
      setComment('');
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    } catch (err) {
      handleFirestoreError(err, 'update' as any, 'assignments');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateAssignment = async () => {
    if (!newAssignment.title || !newAssignment.courseId || !selectedFile) return;
    setLoading(true);
    try {
      const course = courses.find(c => c.id === newAssignment.courseId);
      await addDoc(collection(db, 'assignments'), {
        ...newAssignment,
        courseName: course?.name,
        type: 'task',
        status: 'pending',
        fileName: selectedFile.name,
        fileUrl: URL.createObjectURL(selectedFile),
        createdAt: serverTimestamp()
      });
      setShowAddModal(false);
      setNewAssignment({ title: '', courseId: '', dueDate: '' });
      setSelectedFile(null);
    } catch (err) {
      handleFirestoreError(err, 'create' as any, 'assignments');
    } finally {
      setLoading(false);
    }
  };

  const handleUploadSubmission = async (task: Assignment, file: File) => {
    setLoading(true);
    try {
      await addDoc(collection(db, 'assignments'), {
        title: `REQ: ${task.title}`,
        courseId: task.courseId,
        courseName: task.courseName,
        type: 'submission',
        studentId: user?.id || 'anonymous',
        studentName: user?.name || 'Student',
        fileName: file.name,
        fileUrl: URL.createObjectURL(file),
        status: 'submitted',
        createdAt: serverTimestamp()
      });
      alert('Academic packet transmitted to node: ' + task.courseName);
    } catch (err) {
      handleFirestoreError(err, 'create' as any, 'assignments');
    } finally {
      setLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      if (!newAssignment.title) {
        setNewAssignment(prev => ({ ...prev, title: file.name.split('.')[0] }));
      }
    }
  };

  const handleSubmissionFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0] && targetTask) {
      setPendingFile(e.target.files[0]);
      setShowConfirmModal(true);
    }
  };

  const handleFinalTransmit = async () => {
    if (targetTask && pendingFile) {
      await handleUploadSubmission(targetTask, pendingFile);
      setShowConfirmModal(false);
      setPendingFile(null);
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    }
  };

  const handleDeleteAssignment = async (id: string) => {
    if (!confirm('Permanently delete this assignment and all associated records?')) return;
    try {
      await deleteDoc(doc(db, 'assignments', id));
    } catch (err) {
      handleFirestoreError(err, 'delete' as any, 'assignments');
    }
  };

  const studentTasks = assignments.filter(a => a.type === 'task');
  const submissions = assignments.filter(a => a.type === 'submission');

  return (
    <div className="space-y-gutter pb-xl text-on-surface">
      <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-3xl font-black text-primary tracking-tighter">Academic Assignments</h2>
          <p className="text-xs font-black uppercase tracking-widest text-outline mt-1">Course Distribution Node</p>
        </div>
        {role === UserRole.LECTURER && (
          <button 
            onClick={() => setShowAddModal(true)}
            className="bg-primary text-white px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl hover:bg-primary-container active:scale-95 transition-all flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Deploy Task
          </button>
        )}
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-gutter lg:mt-gutter">
        {/* Active Tasks Feed */}
        <div className="lg:col-span-8 space-y-6">
          <div className="flex items-center gap-2 px-2">
            <BookOpen className="w-4 h-4 text-primary" />
            <h3 className="text-xs font-black uppercase tracking-[0.2em] text-outline">Open Course Tasks</h3>
          </div>
          
          <div className="grid grid-cols-1 gap-4">
            {studentTasks.length === 0 ? (
              <div className="p-20 bg-white border border-dashed border-outline-variant rounded-3xl text-center">
                <History icon={FileCode} className="w-12 h-12 text-slate-200 mx-auto mb-4" />
                <p className="text-xs font-black uppercase tracking-widest text-slate-300">No active tasks detected</p>
              </div>
            ) : (
              studentTasks.map((task) => (
                <motion.div 
                  key={task.id}
                  layout
                  className="bg-white border border-outline-variant rounded-3xl p-6 shadow-sm hover:shadow-md transition-all group"
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div className="flex items-start gap-5">
                      <div className="w-12 h-12 rounded-2xl bg-blue-50 flex items-center justify-center text-primary border border-blue-100 shrink-0">
                        <FileText className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="font-black text-lg text-on-surface leading-tight mb-1">{task.title}</h4>
                        <div className="flex items-center gap-3">
                          <span className="text-[10px] font-black uppercase tracking-widest bg-slate-100 px-2 py-0.5 rounded-full text-slate-600 border border-slate-200">{task.courseName}</span>
                          <div className="flex items-center gap-1 text-[10px] font-bold text-outline uppercase tracking-tighter">
                            <Clock className="w-3 h-3" />
                            Due: {task.dueDate}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <a 
                        href={task.fileUrl} 
                        download={task.fileName}
                        className="flex-1 md:flex-none flex items-center justify-center gap-2 px-6 py-3 bg-slate-50 border border-outline-variant rounded-xl font-black text-[10px] uppercase tracking-widest text-on-surface hover:bg-slate-100 transition-colors shadow-sm"
                      >
                        <Download className="w-3.5 h-3.5" />
                        Task
                      </a>
                      {(role === UserRole.LECTURER || role === UserRole.ADMIN) && (
                        <button 
                          onClick={() => handleDeleteAssignment(task.id)}
                          className="p-3 bg-error/10 text-error rounded-xl hover:bg-error/20 transition-colors shadow-sm"
                        >
                          <Trash2 size={16} />
                        </button>
                      )}
                      {role === UserRole.STUDENT && (
                        <button 
                          onClick={() => { setTargetTask(task); submissionInputRef.current?.click(); }}
                          disabled={loading}
                          className="flex-1 md:flex-none flex items-center justify-center gap-2 px-6 py-3 bg-primary text-white rounded-xl font-black text-[10px] uppercase tracking-widest shadow-lg hover:bg-primary-container transition-all active:scale-95"
                        >
                          {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
                          Transmit
                        </button>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))
            )}
          </div>
        </div>

        {/* Status / History Tracking */}
        <div className="lg:col-span-4 space-y-6">
          <div className="flex items-center gap-2 px-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <h3 className="text-xs font-black uppercase tracking-[0.2em] text-outline">Submission Sync</h3>
          </div>
          
          <div className="bg-white border border-outline-variant rounded-3xl overflow-hidden shadow-sm">
            <div className="p-6 bg-slate-50 border-b border-outline-variant">
              <span className="text-2xl font-black text-on-surface tracking-tighter">{submissions.length}</span>
              <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mt-1">Total Packets Received</p>
            </div>
            <div className="divide-y divide-slate-100 max-h-[400px] overflow-y-auto">
              {submissions.map((sub: any) => (
                <div 
                  key={sub.id} 
                  className={cn(
                    "p-4 flex items-center justify-between hover:bg-slate-50 transition-colors group cursor-pointer",
                    sub.status === 'graded' && "bg-emerald-50/30"
                  )}
                  onClick={() => role === UserRole.LECTURER && setGradingAssignment(sub)}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={cn(
                      "w-8 h-8 rounded-lg flex items-center justify-center border shrink-0",
                      sub.status === 'graded' 
                        ? "bg-emerald-50 text-emerald-600 border-emerald-100" 
                        : "bg-blue-50 text-blue-600 border-blue-100"
                    )}>
                      {sub.status === 'graded' ? <CheckCircle2 size={16} /> : <Clock size={16} />}
                    </div>
                    <div className="min-w-0">
                      <h5 className="text-[10px] font-black uppercase tracking-tight text-on-surface truncate">{sub.studentName}</h5>
                      <div className="flex items-center gap-2">
                        <span className="text-[9px] font-bold text-slate-400 truncate">{sub.courseName}</span>
                        {sub.status === 'graded' && (
                          <span className="text-[9px] font-black text-emerald-600 uppercase tracking-widest bg-emerald-100 px-1 rounded">Score: {sub.grade}</span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    {role === UserRole.LECTURER && (
                      <button 
                        onClick={(e) => { e.stopPropagation(); }}
                        className="p-2 text-slate-300 hover:text-primary transition-colors opacity-0 group-hover:opacity-100"
                      >
                        <a href={sub.fileUrl} download={sub.fileName}>
                          <Download size={14} />
                        </a>
                      </button>
                    )}
                    {(role === UserRole.LECTURER || role === UserRole.ADMIN) && (
                      <button 
                        onClick={(e) => { e.stopPropagation(); handleDeleteAssignment(sub.id); }}
                        className="p-2 text-slate-300 hover:text-error transition-colors opacity-0 group-hover:opacity-100"
                      >
                        <Trash2 size={14} />
                      </button>
                    )}
                  </div>
                </div>
              ))}
              {submissions.length === 0 && (
                <div className="p-10 text-center text-[10px] font-black uppercase tracking-[0.2em] text-slate-200">
                  Waiting for uploads...
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {showSuccess && (
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[300] bg-emerald-600 text-white px-8 py-4 rounded-2xl font-black uppercase tracking-widest shadow-2xl flex items-center gap-3 border border-emerald-400/20"
          >
            <CheckCircle2 className="w-5 h-5" />
            Packet Transmitted Successfully
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showConfirmModal && targetTask && pendingFile && (
          <div className="fixed inset-0 z-[250] flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setShowConfirmModal(false)} className="absolute inset-0 bg-on-surface/60 backdrop-blur-md" />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }} 
              animate={{ scale: 1, opacity: 1 }} 
              exit={{ scale: 0.9, opacity: 0 }} 
              className="relative bg-white w-full max-w-md rounded-3xl p-8 shadow-2xl overflow-hidden border border-outline-variant"
            >
              <div className="absolute top-0 left-0 w-full h-2 bg-primary" />
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                  <FileUp className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-black text-on-surface tracking-tighter uppercase">Confirm Transmission</h3>
              </div>
              
              <div className="space-y-6">
                <div className="p-4 bg-slate-50 rounded-2xl border border-outline-variant">
                  <span className="text-[10px] font-black uppercase tracking-widest text-outline block mb-1">Target Task</span>
                  <p className="text-sm font-black text-on-surface uppercase mb-3">{targetTask.title}</p>
                  
                  <span className="text-[10px] font-black uppercase tracking-widest text-outline block mb-1">Payload Identity</span>
                  <div className="flex items-center gap-3 p-3 bg-white border border-outline-variant rounded-xl">
                    <FileCode className="text-primary w-5 h-5" />
                    <div className="flex-1 min-w-0">
                      <p className="text-[10px] font-black text-on-surface truncate uppercase">{pendingFile.name}</p>
                      <p className="text-[8px] font-bold text-outline uppercase tracking-widest">{(pendingFile.size / 1024).toFixed(1)} KB • LOCAL BUFFER</p>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col gap-3">
                  <button 
                    onClick={handleFinalTransmit}
                    disabled={loading}
                    className="w-full bg-primary text-white py-4 rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-xl hover:bg-primary-container active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                  >
                    {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                    Confirm & Deposit
                  </button>
                  <button 
                    onClick={() => setShowConfirmModal(false)}
                    disabled={loading}
                    className="w-full py-4 text-xs font-black uppercase tracking-widest text-outline hover:bg-slate-50 rounded-2xl transition-colors"
                  >
                    Cancel Transfer
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {gradingAssignment && (
          <div className="fixed inset-0 z-[300] flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setGradingAssignment(null)} className="absolute inset-0 bg-on-surface/60 backdrop-blur-md" />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }} 
              animate={{ scale: 1, opacity: 1 }} 
              exit={{ scale: 0.9, opacity: 0 }} 
              className="relative bg-white w-full max-w-lg rounded-3xl p-8 shadow-2xl overflow-hidden border border-outline-variant"
            >
              <div className="absolute top-0 left-0 w-full h-2 bg-emerald-600" />
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-600">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-black text-on-surface tracking-tighter uppercase">Evaluate Submission</h3>
                </div>
                <button onClick={() => setGradingAssignment(null)} className="p-2 hover:bg-slate-50 rounded-full transition-colors">
                  <X size={20} className="text-outline" />
                </button>
              </div>

              <div className="space-y-6">
                <div className="p-5 bg-slate-50 rounded-2xl border border-outline-variant">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <span className="text-[9px] font-black uppercase tracking-widest text-outline block mb-1">Student Candidate</span>
                      <p className="text-sm font-black text-on-surface uppercase">{gradingAssignment.studentName}</p>
                    </div>
                    <a 
                      href={gradingAssignment.fileUrl} 
                      download={gradingAssignment.fileName}
                      className="flex items-center gap-2 px-4 py-2 bg-white border border-outline-variant rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-slate-100 transition-all shadow-sm"
                    >
                      <Download size={12} />
                      Source Material
                    </a>
                  </div>
                  <div>
                    <span className="text-[9px] font-black uppercase tracking-widest text-outline block mb-1">Target Task</span>
                    <p className="text-xs font-bold text-slate-600 uppercase">{gradingAssignment.title}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Performance Grade (0-100)</label>
                    <input 
                      type="number" 
                      min="0" 
                      max="100"
                      className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-lg font-black outline-none focus:border-emerald-600 transition-all text-center"
                      value={grade}
                      onChange={e => setGrade(e.target.value)}
                      placeholder="--"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Status Protocol</label>
                    <div className="w-full p-4 bg-emerald-50 text-emerald-700 border border-emerald-100 rounded-2xl text-xs font-black uppercase tracking-widest text-center">
                      Ready for Final Sync
                    </div>
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Academic Feedback</label>
                  <textarea 
                    className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-medium outline-none focus:border-emerald-600 transition-all min-h-[120px]"
                    value={comment}
                    onChange={e => setComment(e.target.value)}
                    placeholder="Enter observations and node corrections..."
                  />
                </div>

                <button 
                  onClick={handleGradeSubmission}
                  disabled={loading || !grade}
                  className="w-full bg-emerald-600 text-white py-5 rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-xl hover:bg-emerald-700 active:scale-[0.98] transition-all flex items-center justify-center gap-3 disabled:opacity-50"
                >
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                  Register Final Grade
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setShowAddModal(false)} className="absolute inset-0 bg-on-surface/40 backdrop-blur-sm" />
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="relative bg-white w-full max-w-md rounded-3xl p-8 shadow-2xl">
              <h3 className="text-xl font-black text-primary tracking-tighter mb-8">Deploy Assignment Task</h3>
              <div className="space-y-6">
                <div>
                  <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Task Title</label>
                  <input type="text" className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-bold outline-none border border-outline-variant focus:border-primary transition-all" value={newAssignment.title} onChange={e => setNewAssignment({...newAssignment, title: e.target.value})} />
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Course Node</label>
                  <select className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-bold outline-none border border-outline-variant focus:border-primary transition-all" value={newAssignment.courseId} onChange={e => setNewAssignment({...newAssignment, courseId: e.target.value})}>
                    <option value="">Select Target Course</option>
                    {courses.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Deadline Protocol</label>
                  <input type="date" className="w-full p-4 bg-slate-50 border border-outline-variant rounded-2xl text-sm font-bold outline-none border border-outline-variant focus:border-primary transition-all" value={newAssignment.dueDate} onChange={e => setNewAssignment({...newAssignment, dueDate: e.target.value})} />
                </div>
                <div>
                    <label className="text-[10px] font-black uppercase tracking-widest text-outline mb-2 block">Source Control (Select File)</label>
                    <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileChange} />
                    <button 
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full p-6 border-2 border-dashed border-outline-variant rounded-2xl flex flex-col items-center gap-2 hover:border-primary transition-all group"
                    >
                      <Upload className="w-6 h-6 text-outline group-hover:text-primary" />
                      <span className="text-[10px] font-black uppercase tracking-widest">
                        {selectedFile ? selectedFile.name : 'Open System Folders'}
                      </span>
                    </button>
                </div>
                <button onClick={handleCreateAssignment} disabled={loading || !selectedFile} className="w-full bg-primary text-white py-4 rounded-2xl font-black uppercase tracking-widest shadow-xl flex items-center justify-center gap-2 hover:bg-primary-container active:scale-95 transition-all disabled:opacity-50">
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                  Finalize Task Deployment
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      <input type="file" ref={submissionInputRef} className="hidden" onChange={handleSubmissionFileChange} />
      
      <BrandingFooter />
    </div>
  );
};
