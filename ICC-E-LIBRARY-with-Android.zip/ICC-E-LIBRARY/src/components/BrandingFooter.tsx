import React from 'react';
import { motion } from 'motion/react';

export const BrandingFooter: React.FC = () => {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="mt-16 pt-8 pb-12 border-t border-slate-200 text-center"
    >
      <div className="space-y-4">
        <div className="space-y-1">
          <h2 className="text-xl font-black tracking-tight text-blue-600 uppercase md:text-2xl">
            INTERNATIONAL COMPUTER COLLEGE
          </h2>
          <p className="text-lg font-bold italic text-blue-900 md:text-xl">
            "Learn Today, Lead Tomorrow"
          </p>
        </div>
        
        <div className="pt-4">
          <p className="text-[10px] font-black uppercase tracking-[0.2em] text-outline/60 leading-loose">
            developed By <span className="text-primary">Nigel Maluge</span>
          </p>
          <p className="text-[9px] font-bold uppercase tracking-widest text-outline/40 mt-1">
            © International Computer College 2026
          </p>
        </div>
      </div>
    </motion.div>
  );
};
