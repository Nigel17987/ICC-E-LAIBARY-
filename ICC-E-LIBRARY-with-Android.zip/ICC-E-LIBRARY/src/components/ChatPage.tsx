import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, 
  Paperclip, 
  Smile, 
  PlusCircle, 
  Search, 
  Info, 
  Video,
  Megaphone,
  Download,
  Mic,
  Camera,
  X,
  PhoneOff,
  Maximize2,
  Minimize2,
  FileIcon,
  Play,
  Pause
} from 'lucide-react';
import { IMAGES } from '@/src/constants';
import { cn } from '@/src/lib/utils';
import { BrandingFooter } from './BrandingFooter';

export const ChatPage: React.FC = () => {
  const [message, setMessage] = useState('');
  const [isVideoCallOpen, setIsVideoCallOpen] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isRecordingVideo, setIsRecordingVideo] = useState(false);
  const [showFilePicker, setShowFilePicker] = useState(false);
  const [headerNode, setHeaderNode] = useState('Python Study Node');
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [recordingTime, setRecordingTime] = useState(0);
  const [playingMessageId, setPlayingMessageId] = useState<number | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const videoRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const videoChunksRef = useRef<Blob[]>([]);
  const timerIntervalRef = useRef<number | null>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);
  const recordingVideoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    return () => {
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
        audioPlayerRef.current = null;
      }
    };
  }, []);

  const handleToggleAudio = (msgId: number, url: string) => {
    if (playingMessageId === msgId) {
      audioPlayerRef.current?.pause();
      setPlayingMessageId(null);
    } else {
      // Stop current playback
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
      }

      const audio = new Audio(url);
      audioPlayerRef.current = audio;
      setPlayingMessageId(msgId);

      audio.onended = () => {
        setPlayingMessageId(null);
      };

      audio.play().catch(err => {
        console.error("Playback error:", err);
        setPlayingMessageId(null);
      });
    }
  };

  useEffect(() => {
    if (isRecording || isRecordingVideo) {
      setRecordingTime(0);
      timerIntervalRef.current = window.setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    } else {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    }
    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, [isRecording, isRecordingVideo]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      audioChunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };

      recorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        const audioUrl = URL.createObjectURL(audioBlob);
        
        const newMessage = {
          id: Date.now(),
          type: 'voice',
          sender: 'You',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          duration: formatTime(recordingTime),
          senderType: 'self',
          audioUrl: audioUrl
        };
        
        setMessages(prev => [...prev, newMessage as any]);
        
        // Stop all tracks to release microphone
        stream.getTracks().forEach(track => track.stop());
      };

      recorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Error accessing microphone:", err);
      alert("Please check microphone permissions on your device.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const cancelRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.onstop = null; // Don't trigger the message creation
      mediaRecorderRef.current.stop();
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
      setIsRecording(false);
    }
  };

  const startVideoRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'user' }, 
        audio: true 
      });
      
      if (recordingVideoRef.current) {
        recordingVideoRef.current.srcObject = stream;
      }

      const recorder = new MediaRecorder(stream, { mimeType: 'video/webm' });
      videoRecorderRef.current = recorder;
      videoChunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) videoChunksRef.current.push(e.data);
      };

      recorder.onstop = () => {
        const videoBlob = new Blob(videoChunksRef.current, { type: 'video/webm' });
        const videoUrl = URL.createObjectURL(videoBlob);
        
        const newMessage = {
          id: Date.now(),
          type: 'video_msg',
          sender: 'You',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          duration: formatTime(recordingTime),
          senderType: 'self',
          videoUrl: videoUrl
        };
        
        setMessages(prev => [...prev, newMessage as any]);
        stream.getTracks().forEach(track => track.stop());
      };

      recorder.start();
      setIsRecordingVideo(true);
    } catch (err) {
      console.error("Error accessing camera for video message:", err);
      alert("Please check camera/microphone permissions.");
    }
  };

  const stopVideoRecording = () => {
    if (videoRecorderRef.current && isRecordingVideo) {
      videoRecorderRef.current.stop();
      setIsRecordingVideo(false);
    }
  };

  const cancelVideoRecording = () => {
    if (videoRecorderRef.current && isRecordingVideo) {
      videoRecorderRef.current.onstop = null;
      videoRecorderRef.current.stop();
      videoRecorderRef.current.stream.getTracks().forEach(track => track.stop());
      setIsRecordingVideo(false);
    }
  };

  const toggleMute = () => {
    if (cameraStream) {
      cameraStream.getAudioTracks().forEach(track => {
        track.enabled = isMuted;
      });
      setIsMuted(!isMuted);
    } else {
      setIsMuted(!isMuted);
    }
  };

  useEffect(() => {
    let currentStream: MediaStream | null = null;

    const startCamera = async () => {
      try {
        if (cameraStream) {
          cameraStream.getTracks().forEach(track => track.stop());
        }

        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { facingMode: facingMode }, 
          audio: true 
        });
        setCameraStream(stream);
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
        currentStream = stream;
      } catch (err) {
        console.error("Error accessing camera:", err);
      }
    };

    if (isVideoCallOpen) {
      startCamera();
    } else {
      if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
        setCameraStream(null);
      }
    }

    return () => {
      if (currentStream) {
        currentStream.getTracks().forEach(track => track.stop());
      }
    };
  }, [isVideoCallOpen, facingMode]);

  const toggleCamera = () => {
    setFacingMode(prev => prev === 'user' ? 'environment' : 'user');
  };

  const [messages, setMessages] = useState([
    { id: 1, text: "Has anyone started on the Django project? I'm having trouble setting up the virtual environment.", sender: 'John Doe', time: '10:15 AM', type: 'other', avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCSsgAi1g2HjEb7L3JWCWCGM4AopnspHGYMXlyjFbu7dBxbIB-yzjVBLXOrneO-PxBCPErbdj8i1y56_TeUgOxdkEt_6-jVj1FYVgNbo7tsrhmjbpNVJjW4ORIXhc0Q8uaFOnGxZZR11h9C4VGl8JGN00ewntFqw9FiLvtggJJxJ6nAZd9HEyllfTJbbcPW95GSpiu4IeiPU2UIQaIekZDdhVNCmiAU7PJds8WZqIgz9JPC9pp2dT1WV89R46ncr0tch1zbNM6X5XA' },
    { 
      id: 2, 
      text: "Hello everyone! I've just uploaded the updated Django Project Guide to the resources section.", 
      sender: 'Dr. Sarah Miller', 
      time: '10:30 AM', 
      type: 'announcement',
      avatar: IMAGES.LECTURER_AVATAR 
    },
    { id: 3, type: 'voice', sender: 'You', time: '10:32 AM', duration: '0:12', senderType: 'self' },
    { id: 4, type: 'file', fileName: 'Database_Schema.sqlt', fileSize: '1.2 MB', sender: 'Alice Smith', time: '10:35 AM', senderType: 'other', avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA7qzTBybef-tb88z-xGm9iWiH4yGoI95hOX1hoYQt7teg2rFCumoUC5N95Dh8daAFaXt51GVTCNE2QYvHLrm8DGxGWqzGUf9ZgjyAggP314G51uuB4kCT7mKxBqCeHubIPcDmtwaKHaqUHeGJr50O5r5svxabG-4zaHF_KfueP1NnnT51_5M1wNqHnKLJd8kr5AI1-S8qhFz0_msEWRwj9ktsicQH1HKYLURHbJyM3ttBCtk30rRFu-cLLug4k4yGahmwIUIRfmVQ' },
  ]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
    
    // Automatically update header with the latest file name if available
    const lastFile = [...messages].reverse().find(m => m.type === 'file');
    if (lastFile && (lastFile as any).fileName) {
      setHeaderNode((lastFile as any).fileName.split('.')[0]);
    }
  }, [messages]);

  const handleSend = () => {
    if (!message.trim()) return;
    const newMessage = {
      id: Date.now(),
      text: message,
      sender: 'You',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      type: 'self' as const,
      senderType: 'self'
    };
    setMessages([...messages, newMessage as any]);
    setMessage('');
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const newMessage = {
      id: Date.now(),
      type: 'file',
      fileName: file.name,
      fileSize: (file.size / (1024 * 1024)).toFixed(1) + ' MB',
      sender: 'You',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      senderType: 'self'
    };

    setMessages([...messages, newMessage as any]);
    setHeaderNode(file.name.split('.')[0]); // Update header with file name (without extension)
    setShowFilePicker(false);
    
    // Reset input
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="flex flex-col flex-grow bg-white rounded-2xl border border-outline-variant overflow-hidden shadow-sm h-full max-h-[calc(100dvh-160px)] relative">
      
      {/* Video Call Overlay */}
      <AnimatePresence>
        {isVideoCallOpen && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="absolute inset-0 z-50 bg-on-surface p-6 flex flex-col"
          >
            <div className="flex-1 rounded-3xl bg-slate-800 relative overflow-hidden flex items-center justify-center border border-white/10">
              <img src={IMAGES.LECTURER_AVATAR} className="w-40 h-40 rounded-full border-4 border-primary/40 object-cover" alt="Remote" />
              <div className="absolute bottom-6 right-6 w-48 h-64 bg-slate-700 rounded-2xl border-2 border-white/20 shadow-2xl overflow-hidden z-10 sm:w-48 sm:h-64 w-32 h-44">
                <video 
                  ref={videoRef}
                  autoPlay 
                  playsInline 
                  muted 
                  className={cn(
                    "w-full h-full object-cover",
                    facingMode === 'user' && "-scale-x-100"
                  )}
                />
                {!cameraStream && (
                  <div className="absolute inset-0 flex items-center justify-center bg-slate-800">
                    <span className="text-[10px] font-black uppercase tracking-widest text-white/40">Initializing...</span>
                  </div>
                )}
              </div>
              <div className="absolute top-6 left-6 flex items-center gap-3 bg-black/40 backdrop-blur-md px-4 py-2 rounded-full border border-white/10">
                <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                <span className="text-[10px] font-black uppercase tracking-widest text-white">Live Session: Python Q&A</span>
              </div>
            </div>

            <div className="mt-6 flex items-center justify-center gap-4 sm:gap-6">
              <button 
                onClick={toggleMute}
                className={cn(
                  "w-12 h-12 sm:w-14 sm:h-14 rounded-full flex items-center justify-center transition-all backdrop-blur-md border",
                  isMuted ? "bg-red-500/20 text-red-500 border-red-500/20" : "bg-white/10 text-white border-white/10 hover:bg-white/20"
                )}
              >
                <Mic className="w-5 h-5 sm:w-6 sm:h-6" />
              </button>
              <button 
                onClick={toggleCamera}
                className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-all backdrop-blur-md border border-white/10"
              >
                <Camera className="w-5 h-5 sm:w-6 sm:h-6" />
              </button>
              <button 
                onClick={() => setIsVideoCallOpen(false)}
                className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-red-600 hover:bg-red-700 text-white flex items-center justify-center shadow-xl shadow-red-600/30 active:scale-95 transition-all ring-4 ring-red-600/10"
              >
                <PhoneOff className="w-6 h-6 sm:w-8 sm:h-8" />
              </button>
              <button className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-all backdrop-blur-md border border-white/10">
                <Maximize2 className="w-5 h-5 sm:w-6 sm:h-6" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <header className="flex items-center justify-between px-6 py-4 border-b border-outline-variant bg-surface-container-lowest">
        <div className="flex items-center gap-4">
          <div className="relative">
            <div className="w-12 h-12 rounded-xl bg-primary-container flex items-center justify-center text-white font-black text-lg">PY</div>
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full"></div>
          </div>
          <div>
            <h2 className="text-xl font-bold text-on-surface tracking-tight truncate max-w-[200px] md:max-w-md">
              {headerNode}
            </h2>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black text-green-600 uppercase tracking-widest">Broadcasting Now</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setIsVideoCallOpen(true)}
            className="p-2.5 text-primary hover:bg-primary/5 rounded-xl transition-all hover:scale-110"
          >
            <Video className="w-6 h-6" />
          </button>
          <button className="p-2.5 text-outline hover:bg-surface-container-low rounded-xl transition-colors">
            <Info className="w-5 h-5" />
          </button>
        </div>
      </header>

      <div ref={scrollRef} className="flex-grow overflow-y-auto p-6 space-y-6 bg-slate-50/30">
        <AnimatePresence>
          {messages.map((msg: any) => (
            <motion.div 
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn(
                "flex items-start gap-3",
                msg.senderType === 'self' || msg.type === 'self' ? "ml-auto flex-row-reverse max-w-[85%]" : 
                msg.type === 'announcement' ? "max-w-[95%] mx-auto w-full" : "max-w-[85%]"
              )}
            >
              {msg.type !== 'self' && msg.type !== 'announcement' && msg.senderType !== 'self' && (
                <img src={msg.avatar} className="w-8 h-8 rounded-full border border-outline-variant shadow-sm" alt={msg.sender} />
              )}
              
              <div className={cn("space-y-1", (msg.senderType === 'self' || msg.type === 'self') ? "text-right" : "text-left")}>
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest mx-1">{msg.sender}</span>
                
                {msg.type === 'voice' ? (
                  <div className="bg-primary/5 border border-primary/10 p-3 rounded-2xl flex items-center gap-3 min-w-[200px]">
                    <button 
                      onClick={() => msg.audioUrl && handleToggleAudio(msg.id, msg.audioUrl)}
                      className={cn(
                        "w-8 h-8 rounded-full flex items-center justify-center transition-all shadow-sm active:scale-95",
                        playingMessageId === msg.id ? "bg-red-500 text-white" : "bg-primary text-white"
                      )}
                    >
                      {playingMessageId === msg.id ? (
                        <Pause size={14} className="fill-current" />
                      ) : (
                        <Play size={14} className="fill-current" />
                      )}
                    </button>
                    <div className="flex-1 flex gap-0.5 items-center h-4">
                      {[...Array(20)].map((_, i) => (
                        <div 
                          key={i} 
                          className={cn(
                            "flex-1 rounded-full transition-all duration-300",
                            playingMessageId === msg.id ? "bg-red-600/40 animate-pulse" : "bg-primary/20"
                          )} 
                          style={{ height: `${20 + Math.random() * 80}%` }} 
                        />
                      ))}
                    </div>
                    <span className="text-[10px] font-black text-primary">{msg.duration}</span>
                  </div>
                ) : msg.type === 'video_msg' ? (
                  <div className="bg-black/5 rounded-2xl overflow-hidden border border-outline-variant max-w-[240px]">
                    <video 
                      src={msg.videoUrl} 
                      className="w-full aspect-[3/4] object-cover" 
                      controls 
                    />
                    <div className="p-2 flex justify-between items-center bg-white/50">
                      <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">{msg.duration}</span>
                    </div>
                  </div>
                ) : msg.type === 'file' ? (
                   <div className="bg-white border border-outline-variant p-4 rounded-2xl flex items-center gap-4 shadow-sm max-w-xs text-left">
                     <div className="w-10 h-10 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center border border-orange-100">
                       <FileIcon className="w-6 h-6" />
                     </div>
                     <div className="min-w-0 flex-1">
                       <p className="text-xs font-black text-on-surface truncate">{msg.fileName}</p>
                       <p className="text-[9px] font-bold text-outline uppercase tracking-widest">{msg.fileSize}</p>
                     </div>
                     <button className="text-primary"><Download size={18} /></button>
                   </div>
                ) : msg.type === 'announcement' ? (
                  <div className="bg-primary-container/10 border border-primary-container p-4 rounded-2xl">
                    <p className="text-sm text-on-surface font-medium">{msg.text}</p>
                  </div>
                ) : (
                  <div className={cn(
                    "p-4 shadow-sm text-sm leading-relaxed",
                    (msg.senderType === 'self' || msg.type === 'self') 
                      ? "bg-primary text-white rounded-2xl rounded-tr-none" 
                      : "bg-white border border-outline-variant text-on-surface rounded-2xl rounded-tl-none"
                  )}>
                    {msg.text}
                  </div>
                )}
                <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mx-1">{msg.time}</span>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <footer className="p-3 sm:p-4 border-t border-outline-variant bg-white/80 backdrop-blur-lg sticky bottom-0">
        <div className="flex items-end gap-2 sm:gap-3 max-w-5xl mx-auto">
          {!isRecording && !isRecordingVideo && (
            <div className="flex items-center gap-0.5 pb-1 sm:gap-1">
              <div className="relative">
                <button 
                  onClick={() => setShowFilePicker(!showFilePicker)}
                  className="p-2 sm:p-2.5 text-slate-400 hover:text-primary hover:bg-primary/5 rounded-full transition-all active:scale-90"
                >
                  <PlusCircle className="w-5 h-5 sm:w-6 sm:h-6" />
                </button>
                <AnimatePresence>
                  {showFilePicker && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.95 }}
                      className="absolute bottom-full left-0 mb-3 bg-white border border-outline-variant p-2 rounded-2xl shadow-2xl flex flex-col gap-1 ring-1 ring-black/5 z-50 min-w-[180px]"
                    >
                      <button 
                        onClick={() => fileInputRef.current?.click()}
                        className="flex items-center gap-3 p-3 hover:bg-slate-50 rounded-xl transition-all text-[11px] font-black uppercase tracking-[0.1em] text-on-surface whitespace-nowrap"
                      >
                        <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center">
                          <FileIcon className="w-4 h-4 text-blue-500" />
                        </div>
                        Document Node
                      </button>
                      <button 
                        onClick={() => {
                          if (fileInputRef.current) {
                            fileInputRef.current.setAttribute('capture', 'environment');
                            fileInputRef.current.click();
                          }
                        }}
                        className="flex items-center gap-3 p-3 hover:bg-slate-50 rounded-xl transition-all text-[11px] font-black uppercase tracking-[0.1em] text-on-surface whitespace-nowrap"
                      >
                        <div className="w-8 h-8 rounded-lg bg-emerald-50 flex items-center justify-center">
                          <Camera className="w-4 h-4 text-emerald-500" />
                        </div>
                        Capture Packet
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
              <input 
                type="file" 
                ref={fileInputRef} 
                className="hidden" 
                onChange={handleFileSelect}
              />
            </div>
          )}
          
          <div className="flex-grow relative min-h-[44px]">
            {isRecording ? (
              <div className="w-full bg-red-500/5 border border-red-500/20 rounded-2xl px-4 py-3 flex items-center justify-between shadow-inner">
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full bg-red-600 animate-pulse shadow-[0_0_8px_rgba(220,38,38,0.4)]" />
                    <span className="text-[10px] font-black uppercase tracking-[0.15em] text-red-600">Audio Uplink</span>
                  </div>
                  <span className="text-base font-black text-red-600 font-mono tracking-tighter">{formatTime(recordingTime)}</span>
                </div>
                <div className="flex items-center gap-3">
                  <button onClick={cancelRecording} className="p-2 text-red-400 hover:text-red-600 transition-colors">
                    <X size={18} />
                  </button>
                  <button onClick={stopRecording} className="bg-red-600 text-white px-5 py-2 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg shadow-red-600/20 active:scale-95 transition-all">Submit</button>
                </div>
              </div>
            ) : isRecordingVideo ? (
              <div className="w-full bg-emerald-500/5 border border-emerald-500/20 rounded-2xl p-2.5 flex items-center gap-4 shadow-inner">
                <div className="w-20 h-28 bg-on-surface rounded-xl overflow-hidden border-2 border-emerald-500/30 shrink-0 shadow-lg">
                  <video ref={recordingVideoRef} autoPlay playsInline muted className="w-full h-full object-cover -scale-x-100" />
                </div>
                <div className="flex-grow flex flex-col justify-center">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse" />
                    <span className="text-[10px] font-black uppercase tracking-widest text-emerald-600">Visual Feed</span>
                  </div>
                  <span className="text-2xl font-black text-emerald-700 font-mono tracking-tighter mb-2">{formatTime(recordingTime)}</span>
                  <div className="flex items-center gap-4">
                    <button onClick={cancelVideoRecording} className="text-[10px] font-black uppercase text-slate-400 hover:text-red-500 transition-colors">Terminate</button>
                    <button onClick={stopVideoRecording} className="bg-emerald-600 text-white px-5 py-2 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg shadow-emerald-600/20 active:scale-95 transition-all flex items-center gap-2">
                      <Send size={12} />
                      Send
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <textarea 
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSend())}
                className="w-full bg-slate-50 border border-outline-variant focus:border-primary rounded-[24px] px-5 py-3 text-sm sm:text-base focus:ring-0 resize-none transition-all duration-200 min-h-[48px] max-h-[120px] shadow-sm font-medium"
                placeholder="Type your message..."
                rows={1}
                style={{ height: message ? 'auto' : '48px' }}
              />
            )}
          </div>

          {!message.trim() && !isRecording && !isRecordingVideo ? (
            <div className="flex items-center gap-1 pb-1">
              <button 
                onClick={startRecording}
                className="p-3 rounded-full bg-slate-100 text-slate-500 hover:text-primary hover:bg-primary/5 transition-all active:scale-90 shadow-sm"
                title="Voice Message"
              >
                <Mic className="w-5 h-5 sm:w-6 sm:h-6" />
              </button>
              <button 
                onClick={startVideoRecording}
                className="p-3 rounded-full bg-slate-100 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 transition-all active:scale-90 shadow-sm"
                title="Video Message"
              >
                <Video className="w-5 h-5 sm:w-6 sm:h-6" />
              </button>
            </div>
          ) : !isRecording && !isRecordingVideo ? (
            <div className="pb-1">
              <button 
                onClick={handleSend}
                className="p-3.5 rounded-full bg-primary text-white shadow-lg shadow-primary/20 hover:scale-105 active:scale-95 transition-all flex items-center justify-center"
              >
                <Send className="w-5 h-5 sm:w-6 sm:h-6 fill-current" />
              </button>
            </div>
          ) : null}
        </div>
      </footer>

      <BrandingFooter />
    </div>
  );
};
