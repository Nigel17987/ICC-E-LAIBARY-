import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';
import { Header, BottomNav } from '@/src/components/Navigation';
import { StudentDashboard } from '@/src/components/StudentDashboard';
import { LecturerDashboard } from '@/src/components/LecturerDashboard';
import { AdminDashboard } from '@/src/components/AdminDashboard';
import { LibraryPage } from '@/src/components/LibraryPage';
import { ChatPage } from '@/src/components/ChatPage';
import { CalendarPage } from '@/src/components/CalendarPage';
import { AssignmentsPage } from '@/src/components/AssignmentsPage';
import { UserCircle } from 'lucide-react';
import { LoginPage } from '@/src/components/LoginPage';
import { UserRole } from '@/src/constants';

import { db, auth } from '@/src/lib/firebase';
import { collection, query, orderBy, limit, onSnapshot } from 'firebase/firestore';
import { onAuthStateChanged, signInAnonymously } from 'firebase/auth';
import { Bell, X as XIcon, Loader2 } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';

const MainApp: React.FC = () => {
  const [role, setRole] = useState<UserRole | null>(null);
  const [user, setUser] = useState<any>(null);
  const [announcement, setAnnouncement] = useState<any>(null);
  const [showToast, setShowToast] = useState(false);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const navigate = useNavigate();

  // Handle Firebase Auth state with safety timeout
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (authenticatedUser) => {
      setIsAuthReady(true);
    });

    // Safety timeout: If Firebase doesn't respond in 0.8 seconds, proceed anyway
    // This handles misconfigured Firebase or slow connections
    const timer = setTimeout(() => {
      setIsAuthReady(true);
    }, 800);

    return () => {
      unsub();
      clearTimeout(timer);
    };
  }, []);

  // Simple auth simulation
  useEffect(() => {
    const savedRole = localStorage.getItem('icc_role') as UserRole;
    if (savedRole) setRole(savedRole);
    
    const savedUser = localStorage.getItem('icc_user');
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (e) {
        console.error("Failed to parse saved user", e);
      }
    }
  }, []);

  // Real-time notifications (Now handled in Header)
  /*
  useEffect(() => {
    if (!role || !isAuthReady) return;

    const q = query(collection(db, 'announcements'), orderBy('createdAt', 'desc'), limit(1));
    const unsub = onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const data = snapshot.docs[0].data();
        setAnnouncement(data);
        setShowToast(true);
        setTimeout(() => setShowToast(false), 10000);
      }
    }, (error) => {
      console.warn("Announcement listener restricted or initial fetch:", error);
    });

    return () => unsub();
  }, [role, isAuthReady]);
  */

  const handleLogin = (selectedRole: UserRole, userData?: any) => {
    setRole(selectedRole);
    setUser(userData);
    localStorage.setItem('icc_role', selectedRole);
    if (userData) {
      localStorage.setItem('icc_user', JSON.stringify(userData));
    }
  };

  const handleLogout = () => {
    setRole(null);
    setUser(null);
    localStorage.removeItem('icc_role');
    localStorage.removeItem('icc_user');
    auth.signOut();
  };

  if (!isAuthReady) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-12 h-12 text-primary animate-spin" />
          <p className="text-xs font-black uppercase tracking-[0.3em] text-slate-400">ICC E-LIBRARY</p>
        </div>
      </div>
    );
  }

  if (!role) {
    return <LoginPage onLogin={handleLogin} />;
  }

  const renderDashboard = () => {
    switch (role) {
      case UserRole.LECTURER:
        return <LecturerDashboard user={user} />;
      case UserRole.ADMIN:
        return <AdminDashboard user={user} />;
      default:
        return <StudentDashboard user={user} />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header role={role} />
      
      <main className="max-w-[1280px] mx-auto pt-20 md:pt-24 pb-28 md:pb-32 px-4 md:px-8 min-h-[calc(100dvh-5rem)]">
        <Routes>
          <Route path="/" element={renderDashboard()} />
          <Route path="/library" element={<LibraryPage />} />
          <Route path="/chat" element={<ChatPage />} />
          <Route path="/calendar" element={<CalendarPage />} />
          <Route path="/assignments" element={<AssignmentsPage />} />
          <Route path="*" element={renderDashboard()} />
        </Routes>
      </main>

      <BottomNav />

      {/* Role Switcher Floating Action */}
      <div className="fixed bottom-24 right-4 z-[100] flex flex-col gap-2 scale-90 md:scale-100">
        <button 
          onClick={handleLogout}
          className="bg-red-500/90 backdrop-blur-md text-white p-3.5 rounded-full shadow-2xl hover:bg-red-600 transition-all flex items-center justify-center shrink-0 border-2 border-white/20 active:scale-90"
          title="Logout"
        >
          <UserCircle size={22} />
        </button>
      </div>

      
    </div>
  );
};

export default function App() {
  return (
    <Router>
      <MainApp />
    </Router>
  );
}
