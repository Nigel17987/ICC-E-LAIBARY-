/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export const IMAGES = {
  LOGO: '/logo.png',
  STUDENT_AVATAR: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAhrAtWjV3ghGlMe2CMDjfAfxwa5NG_T1hR4NzndMtnIaPkKKwgBrMH-zEOugJkoKCUQgGrC7bvOrWslR23e4PuP4SF1O21Dp7kz3dBzyIKI5q54N6V71Yzr8b7E6vcUcHDdS0WYFt7pE2NlRTIPWoe0LMhPTv3e2eg9lpUbxeFcxos71NmG8ln6T2f1Lwuz4zAS_fGMRFBk3RDpxGF9tD7JGA85h0ge-sV9fPQnTeQDjrT7Dwbax9uZQ3PaT9XaNRyO5uCSzmTkss',
  LECTURER_AVATAR: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAp5MpFMTaAAK3c2m3FxITu7Eu9NrC6To-HucMNRFXW_pSQ0P9_4AT8lDNtJCsBFIFkIwOeOZqH9AKWUrIlxEmN0UHFh_tIHzpm1BFJ4s2ekqqkHVvOznsY6crDH1A1kIVJTeofeL3-QbnPV1jZ72znGsOZCflJYNNedZGS0hd3lT281jSHHd92swuX_ZTAxfRGRtcgycoswG0cfaWwbrJAdiLJttVRZ2kfHW3KMRIYmB1p8-gazXhWggjGOzBzftNqcg9eJ1e3CJ4',
  LIBRARY_HERO: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDQZw90mcgakKedRtLvf4IPIVSACBPBv2ZRY_75QaX3PsMWj1ynPSHxkfYIoiogHJ8osrStUbFaLfWN8EYpokBMD_plfGyBW6a4_m7HPHfw--Vgvz-X4UUHvXt6mhadyu5yTlj1CWViggcJbI_FECEw_Apd6r43FLa5wvU_w2Jqr8j3ily5FhAxtcinB3FnFogrqXzXJGU2uJK-4F413Ls3AYsC2O4tE5IjnjCpdkGjLJzf3wfjwU9fy1nMKdYyTqWfwD1PLsqFw3w',
  RECOMMENDATION: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCAHj1UdtryVUQNgw4_CoiEy8F5xG7S2bjbnzAHGKVKE9pYfuj4_E34fQMQttr4vDh0JSnVlsO5_LxjDc3i8ze_jb4PNj4EfnQrrzu8j1aPNrrWqIQek5yycbn2NLgFScuRAWsMVkvbRWn0JRZ4Rl__paN60SzQ7lbPvviY53eNohuQsT48QnfwHVuKLLlj996-c0avbY5k7xJwZUpRhojhDKSYUNAlBbCXNG-UiueyawrbvYqAyMtzy6ON5prURlkTe-93RPItU6s',
  COURSE_1: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAKUB_TgywcAjChIuIbFpbnLLW90kHGgS8vdPo23YQH-_Ucz0S4DQcuhO3zwZvuNyxp4Qnz0jEEkCgMrHbas3Hzp0X3VmqyDP0Ecs-YkgXNB4CN6yJxbmmUPtDlROOgXSwFxx2OQki-0bXISSECWHtwwZrH9smHzTC9hOAiewtysGxNVpxCFsb2sWgjONWc9x4_2EyPBsLSga5IjQGmC_7EZHsm4JSU_PtxesKDjAhHsx5-vafVAwh-q-ljryZYItbgab9OM02i7fM',
  COURSE_2: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBa6PCxJUAGr8oucUbpm8CvoiE5nqAt0L8X7jyaLc8VxMbY6RqzWyR-CpvkKMAtOysB1xreZ3YS6qKm2dvnSQUfwBiS3910T_Fh0O9EQhcGWKSfMq43_5RgUNu2l8uqArD8WrYAUcUV83KiLMgNBhCegXPmgiayilGtyI28KO6gX2q_4PgMq4HbCnBMaegNJTl9_j1tiXWzVmdcwtYuyOqtWBwP2sSvL2gTcMJ_S8V7NKZsCjka56WQOueFMjQxdGnO5WH5DZWTIHI',
  CALENDAR_PROMO: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCCcCMzf-g2F0Zj7K5i2JmncQeFzlZnDobdnAyBWGDPwqGH7pRpfh5SSENsNIQnRVRtE566tfw57HbvnIP9CzATf_wh2-OZm4jUFfF67QZQ58roCxSvvJMZXeRI1wV90EJHI0k2drg6k2KLdTXBV7n3PMdTcWG8ih58a4TsBuPSM5D4sHF8Y0hpfqA-paoymDosnqUz0ManBVbDOyPcnCGh0rMCOj6DJDihlbCL9sgPb9yhQXjk7sguJD6DriNq8qgD1MRpdpV8blA',
  ADMIN_BG: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAX7C7KTqdgAoRVC4FlIUEw5uU2HKSBXdVB21nlwmqiHgJUyROTsYirP_UNMdcc_Lx2aCeCYLT9jVHY6Sd0X6pR1YiaxOz8JWLLKPLzdHC8UipSheYBdhJIsOINnVW4QmwaqeAaKalpz9NcuZyf0rB3ECnXQMHjjyZiAqh86YwkngGC-u0wl0ObkXF_2yLTdbQD4Wf73Eud7BR3TVlHf49SNGpkekDECfWHyARnn6xceEy2p63BAYwhtLvhYcKPIPIK5ruubc18t3Q',
};

export enum UserRole {
  STUDENT = 'student',
  LECTURER = 'lecturer',
  ADMIN = 'admin',
}

export interface User {
  id: string;
  name: string;
  role: UserRole;
  avatar: string;
  department?: string;
  semester?: string;
}

export const MOCK_USERS: Record<UserRole, User> = {
  [UserRole.STUDENT]: {
    id: 'ICC-2024-001',
    name: 'Alexander Julian',
    role: UserRole.STUDENT,
    avatar: IMAGES.STUDENT_AVATAR,
    department: 'Computer Science',
    semester: 'Fall 2024',
  },
  [UserRole.LECTURER]: {
    id: 'ICC-FAC-345',
    name: 'Prof. Henderson',
    role: UserRole.LECTURER,
    avatar: IMAGES.LECTURER_AVATAR,
    department: 'Software Engineering',
  },
  [UserRole.ADMIN]: {
    id: 'ICC-ADM-999',
    name: 'Super Admin',
    role: UserRole.ADMIN,
    avatar: IMAGES.LOGO,
  },
};
